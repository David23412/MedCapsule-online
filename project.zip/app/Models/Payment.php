<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'course_id',
        'reference_number',
        'amount',
        'payment_method',
        'status',
        'payment_data',
        'paid_at',
    ];

    protected $casts = [
        'payment_data' => 'json',
        'paid_at' => 'datetime',
    ];

    /**
     * Get the user that made the payment
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the course that was paid for
     */
    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }

    /**
     * Mark a payment as completed and enroll the user in the course
     */
    public function markAsPaid()
    {
        $this->status = 'completed';
        $this->paid_at = now();
        $this->save();

        // Enroll the user in the course
        $this->user->courses()->syncWithoutDetaching([$this->course_id]);

        // Create a notification
        app(NotificationService::class)->createPaymentSuccessNotification(
            $this->user,
            $this->course->name,
            $this->amount
        );

        return $this;
    }
}
