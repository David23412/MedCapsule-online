<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Review Your Mistakes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.95);
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0;
        }

        .navbar-brand {
            color: #007bff;
            font-weight: 700;
            font-size: 1.5rem;
            text-decoration: none;
            display: flex;
            align-items: center;
            transition: transform 0.3s ease;
        }

        .navbar-brand:hover {
            color: #0056b3;
            transform: translateY(-1px);
        }

        .nav-links {
            display: flex;
            gap: 1.5rem;
            align-items: center;
        }

        .nav-link {
            color: #495057;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: #007bff;
            background-color: #f8f9fa;
            transform: translateY(-1px);
        }

        .main-content {
            margin-top: 80px;
            padding: 2rem;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }

        .header-section {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
        }

        h1 {
            color: #2c3e50;
            font-weight: 600;
            margin: 0;
        }

        .learn-mistakes-btn {
            background: linear-gradient(135deg, #ff4d4d, #ff1a1a);
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(255, 26, 26, 0.2);
        }

        .learn-mistakes-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(255, 26, 26, 0.3);
            color: white;
        }

        .mistake-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
        }

        .mistake-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }

        .question-text {
            font-size: 1.1rem;
            color: #2c3e50;
            margin-bottom: 1rem;
            font-weight: 500;
        }

        .answer-section {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .answer-item {
            padding: 0.8rem;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .answer-label {
            font-weight: 500;
            min-width: 80px;
        }

        .answer-text {
            flex: 1;
        }

        .incorrect-answer {
            background-color: #fff1f0;
            border: 1px solid #ffa39e;
            color: #f5222d;
        }

        .correct-answer {
            background-color: #e3fcef;
            border: 1px solid #b7eb8f;
            color: #00a854;
        }

        .remove-btn {
            background: none;
            border: none;
            color: #ff4d4d;
            cursor: pointer;
            padding: 0.5rem;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .remove-btn:hover {
            background-color: #fff1f0;
            transform: scale(1.1);
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        .empty-state i {
            font-size: 3rem;
            color: #007bff;
            margin-bottom: 1rem;
        }

        .empty-state h3 {
            color: #2c3e50;
            margin-bottom: 0.5rem;
        }

        .empty-state p {
            color: #6c757d;
            margin-bottom: 1.5rem;
        }

        @media (max-width: 768px) {
            .header-section {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }

            .learn-mistakes-btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <div class="nav-links">
                <a href="<?php echo e(url()->previous()); ?>" class="nav-link">← Back</a>
                <a href="/" class="nav-link">Home</a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <div class="header-section">
                <h1>Review Your Mistakes</h1>
                <a href="<?php echo e(route('mistakes.learn')); ?>" class="learn-mistakes-btn">
                    <i class="fas fa-graduation-cap"></i>
                    Learn Mistakes
                </a>
            </div>

            <?php if($mistakes->isEmpty()): ?>
                <div class="empty-state">
                    <i class="fas fa-check-circle"></i>
                    <h3>No Mistakes Yet!</h3>
                    <p>Great job! You haven't made any mistakes yet.</p>
                    <p>Keep up the good work!</p>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $mistakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mistake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mistake-card" data-question-id="<?php echo e($mistake->question_id); ?>">
                        <div class="question-text">
                            <?php echo e($mistake->question->question); ?>

                        </div>
                        <div class="answer-section">
                            <div class="answer-item incorrect-answer">
                                <span class="answer-label">Your Answer:</span>
                                <span class="answer-text"><?php echo e($mistake->question->{'option_' . strtolower($mistake->submitted_answer)}); ?></span>
                            </div>
                            <div class="answer-item correct-answer">
                                <span class="answer-label">Correct:</span>
                                <span class="answer-text"><?php echo e($mistake->question->{'option_' . strtolower($mistake->question->correct_answer)}); ?></span>
                            </div>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <div class="text-muted">
                                Last attempted: <?php echo e($mistake->last_attempt_date->format('M d, Y')); ?>

                            </div>
                            <button class="remove-btn" onclick="removeMistake(<?php echo e($mistake->question_id); ?>)">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

    <script>
        function removeMistake(questionId) {
            if (confirm('Are you sure you want to remove this mistake?')) {
                fetch(`/mistakes/${questionId}/remove`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
                        'Accept': 'application/json'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Remove the mistake card from the DOM
                        document.querySelector(`[data-question-id="${questionId}"]`).remove();
                        
                        // Check if there are any mistakes left
                        const remainingMistakes = document.querySelectorAll('.mistake-card');
                        if (remainingMistakes.length === 0) {
                            // Show empty state
                            document.querySelector('.container').innerHTML = `
                                <div class="empty-state">
                                    <i class="fas fa-check-circle"></i>
                                    <h3>No Mistakes Left!</h3>
                                    <p>Great job! You've removed all your mistakes.</p>
                                    <p>Keep up the good work!</p>
                                </div>
                            `;
                        }
                    } else {
                        alert('Failed to remove mistake. Please try again.');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while removing the mistake.');
                });
            }
        }
    </script>
</body>
</html><?php /**PATH /Users/davidgeorge/Documents/Medcapsule/resources/views/mistakes.blade.php ENDPATH**/ ?>