<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MedCapsule - Home</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <!-- Custom Styles -->
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
            scroll-behavior: smooth;
        }

        /* Navbar */
        .navbar {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease-in-out;
            padding: 1rem 0;
        }

        .navbar-brand {
            color: #2196f3 !important;
            font-weight: 700;
            font-size: 1.8rem;
            transition: transform 0.3s ease;
        }

        .navbar-brand:hover {
            transform: translateY(-2px);
        }

        .navbar-nav .nav-link {
            color: #333 !important;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease-in-out;
            margin: 0 0.5rem;
        }

        .navbar-nav .nav-link:hover {
            color: #2196f3 !important;
            background: rgba(33, 150, 243, 0.1);
            transform: translateY(-2px);
        }

        .navbar-toggler {
            border: none;
            padding: 0.5rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .navbar-toggler:hover {
            background: rgba(33, 150, 243, 0.1);
        }

        .navbar-toggler:focus {
            box-shadow: none;
        }

        /* Hero Section */
        .hero-section {
            position: relative;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 2rem;
            overflow: hidden;
        }

        .hero-section h1 {
            font-size: 3.5rem;
            font-weight: 700;
            color: #2196f3;
            margin-bottom: 1rem;
            position: relative;
            z-index: 1;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
        }

        .hero-section p {
            font-size: 1.2rem;
            color: #666;
            margin-bottom: 2rem;
            position: relative;
            z-index: 1;
            text-shadow: 1px 1px 2px rgba(255, 255, 255, 0.8);
        }

        .hero-section .btn {
            position: relative;
            z-index: 1;
        }

        .btn-primary {
            padding: 15px 40px;
            font-size: 1.5rem;
            border-radius: 50px;
            background: #2196f3;
            border: none;
            box-shadow: 0 4px 12px rgba(33, 150, 243, 0.3);
            font-weight: 600;
            transition: all 0.3s ease-in-out;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-4px) scale(1.05);
            box-shadow: 0 6px 15px rgba(33, 150, 243, 0.4);
        }

        /* Features Section */
        .features {
            text-align: center;
            padding: 60px 0;
            background-color: #fff;
            animation: fadeSlideIn 1s ease-out;
        }

        .features h2 {
            color: #2196f3;
            font-weight: 600;
            text-align: left;
            margin-bottom: 2rem;
        }

        .features .feature-box {
            padding: 30px;
            border-radius: 10px;
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }

        .features .feature-box:hover {
            transform: translateY(-10px);
            box-shadow: 0 6px 15px rgba(0, 123, 255, 0.2);
        }

        .features .feature-box i {
            font-size: 3rem;
            color: #007bff;
            margin-bottom: 15px;
        }

        /* Footer */
        .footer {
            background: #343a40;
            color: white;
            padding: 50px 0;
            text-align: center;
            animation: fadeSlideIn 1s ease-out;
        }

        .footer a {
            color: #007bff;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        /* Animations */
        @keyframes fadeSlideIn {
            0% { opacity: 0; transform: translateY(-20px); }
            100% { opacity: 1; transform: translateY(0); }
        }

        @keyframes fadeIn {
            0% { opacity: 0; }
            100% { opacity: 1; }
        }

        /* Header Styles */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .logo img {
            height: 40px;
        }

        .main-nav {
            display: flex;
            gap: 1.5rem;
        }

        .nav-link {
            color: #333;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            background: #f5f5f5;
            color: #2196f3;
        }

        /* Profile Section Styles */
        .profile-section {
            position: relative;
        }

        .profile-dropdown {
            position: relative;
        }

        .profile-button {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: none;
            border: none;
            padding: 0.5rem;
            cursor: pointer;
            border-radius: 25px;
            transition: all 0.3s ease;
        }

        .profile-button:hover {
            background: #f5f5f5;
        }

        .profile-circle {
            width: 40px;
            height: 40px;
            background: #2196f3;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }

        .profile-circle.large {
            width: 60px;
            height: 60px;
            font-size: 1.8rem;
        }

        .profile-name {
            font-weight: 500;
            color: #333;
        }

        .profile-menu {
            position: absolute;
            top: 100%;
            right: 0;
            width: 300px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            margin-top: 0.5rem;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }

        .profile-dropdown:hover .profile-menu {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .profile-header {
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .profile-info h3 {
            margin: 0;
            font-size: 1.2rem;
            color: #333;
        }

        .profile-info p {
            margin: 0.25rem 0 0;
            color: #666;
            font-size: 0.9rem;
        }

        .profile-stats {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
            padding: 1.5rem;
            border-bottom: 1px solid #eee;
        }

        .stat-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 0.5rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .stat-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .progress-circle {
            position: relative;
            width: 80px;
            height: 80px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .progress-circle svg {
            transform: rotate(-90deg);
        }

        .progress-circle circle {
            fill: none;
            stroke-width: 6;
            stroke-linecap: round;
        }

        .progress-circle .progress-bg {
            stroke: #e9ecef;
        }

        .progress-circle .progress-fill {
            stroke: #2196f3;
            transition: stroke-dashoffset 0.5s ease;
        }

        .progress-value {
            position: absolute;
            font-size: 1.5rem;
            font-weight: bold;
            color: #2196f3;
        }

        .stat-label {
            font-size: 0.9rem;
            color: #666;
            font-weight: 500;
        }

        .streak-indicator {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem 1rem;
            background: linear-gradient(45deg, #ff6b6b, #ff8e8e);
            border-radius: 25px;
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
        }

        .streak-value {
            font-size: 2rem;
            font-weight: bold;
            color: white;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .streak-fire {
            font-size: 2.5rem;
            color: #ffd700;
            filter: drop-shadow(0 0 5px rgba(255, 215, 0, 0.5));
            animation: flame 1.5s infinite;
        }

        @keyframes flame {
            0% { 
                transform: scale(1) rotate(0deg) translateY(0);
                filter: drop-shadow(0 0 5px rgba(255, 215, 0, 0.5));
            }
            25% { 
                transform: scale(1.2) rotate(5deg) translateY(-5px);
                filter: drop-shadow(0 0 8px rgba(255, 215, 0, 0.7));
            }
            50% { 
                transform: scale(1.1) rotate(-5deg) translateY(0);
                filter: drop-shadow(0 0 6px rgba(255, 215, 0, 0.6));
            }
            75% { 
                transform: scale(1.3) rotate(5deg) translateY(-8px);
                filter: drop-shadow(0 0 10px rgba(255, 215, 0, 0.8));
            }
            100% { 
                transform: scale(1) rotate(0deg) translateY(0);
                filter: drop-shadow(0 0 5px rgba(255, 215, 0, 0.5));
            }
        }

        .profile-actions {
            padding: 0.5rem;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            color: #333;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .menu-item:hover {
            background: #f5f5f5;
            color: #2196f3;
        }

        .menu-item i {
            width: 20px;
            text-align: center;
        }

        .menu-divider {
            height: 1px;
            background: #eee;
            margin: 0.5rem 0;
        }

        .menu-item.logout {
            color: #f44336;
        }

        .menu-item.logout:hover {
            background: #ffebee;
            color: #f44336;
        }

        /* Interactive Background Styles */
        .interactive-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        }

        .floating-elements {
            position: absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }

        .floating-element {
            position: absolute;
            background: linear-gradient(45deg, rgba(33, 150, 243, 0.15), rgba(33, 150, 243, 0.05));
            border-radius: 50%;
            filter: blur(3px);
            animation: float-element 20s infinite ease-in-out;
        }

        .floating-element::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 100%;
            height: 100%;
            background: inherit;
            border-radius: 50%;
            filter: blur(4px);
            opacity: 0.5;
        }

        .floating-element:nth-child(1) {
            width: 500px;
            height: 500px;
            top: -250px;
            left: -250px;
            animation-delay: 0s;
        }

        .floating-element:nth-child(2) {
            width: 400px;
            height: 400px;
            top: 50%;
            right: -200px;
            animation-delay: -5s;
        }

        .floating-element:nth-child(3) {
            width: 300px;
            height: 300px;
            bottom: -150px;
            left: 20%;
            animation-delay: -10s;
        }

        .floating-element:nth-child(4) {
            width: 250px;
            height: 250px;
            top: 30%;
            left: 40%;
            animation-delay: -15s;
        }

        .floating-element:nth-child(5) {
            width: 200px;
            height: 200px;
            bottom: 20%;
            right: 15%;
            animation-delay: -20s;
        }

        .floating-element:nth-child(6) {
            width: 150px;
            height: 150px;
            top: 60%;
            left: 10%;
            animation-delay: -25s;
        }

        .floating-element:nth-child(7) {
            width: 120px;
            height: 120px;
            top: 20%;
            right: 30%;
            animation-delay: -30s;
        }

        .floating-element:nth-child(8) {
            width: 100px;
            height: 100px;
            bottom: 40%;
            left: 50%;
            animation-delay: -35s;
        }

        @keyframes float-element {
            0% {
                transform: translate(0, 0) rotate(0deg) scale(1);
                opacity: 0.3;
            }
            25% {
                transform: translate(200px, 200px) rotate(90deg) scale(1.3);
                opacity: 0.6;
            }
            50% {
                transform: translate(0, 400px) rotate(180deg) scale(1);
                opacity: 0.3;
            }
            75% {
                transform: translate(-200px, 200px) rotate(270deg) scale(0.7);
                opacity: 0.6;
            }
            100% {
                transform: translate(0, 0) rotate(360deg) scale(1);
                opacity: 0.3;
            }
        }

        .connecting-lines {
            position: absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }

        .line {
            position: absolute;
            background: linear-gradient(90deg, rgba(33, 150, 243, 0.15), rgba(33, 150, 243, 0.05));
            height: 2px;
            transform-origin: left center;
            animation: line-animation 12s infinite ease-in-out;
        }

        .line:nth-child(1) {
            top: 20%;
            left: 0;
            width: 100%;
            animation-delay: 0s;
        }

        .line:nth-child(2) {
            top: 40%;
            left: 0;
            width: 100%;
            animation-delay: -3s;
        }

        .line:nth-child(3) {
            top: 60%;
            left: 0;
            width: 100%;
            animation-delay: -6s;
        }

        .line:nth-child(4) {
            top: 80%;
            left: 0;
            width: 100%;
            animation-delay: -9s;
        }

        @keyframes line-animation {
            0% {
                transform: scaleX(0);
                opacity: 0;
            }
            50% {
                transform: scaleX(1);
                opacity: 0.4;
            }
            100% {
                transform: scaleX(0);
                opacity: 0;
            }
        }

        .pulse-circles {
            position: absolute;
            width: 100%;
            height: 100%;
            pointer-events: none;
        }

        .pulse-circle {
            position: absolute;
            border: 2px solid rgba(33, 150, 243, 0.15);
            border-radius: 50%;
            animation: pulse-circle 6s infinite ease-out;
        }

        .pulse-circle:nth-child(1) {
            top: 30%;
            left: 30%;
            width: 300px;
            height: 300px;
            animation-delay: 0s;
        }

        .pulse-circle:nth-child(2) {
            top: 60%;
            left: 60%;
            width: 200px;
            height: 200px;
            animation-delay: -2s;
        }

        .pulse-circle:nth-child(3) {
            top: 20%;
            left: 70%;
            width: 150px;
            height: 150px;
            animation-delay: -4s;
        }

        @keyframes pulse-circle {
            0% {
                transform: scale(1);
                opacity: 0.4;
            }
            100% {
                transform: scale(2.5);
                opacity: 0;
            }
        }

        .gradient-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: radial-gradient(circle at center, transparent 0%, rgba(255, 255, 255, 0.9) 100%);
            z-index: -1;
            pointer-events: none;
        }

        .noise-texture {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E");
            opacity: 0.08;
            z-index: -1;
            pointer-events: none;
        }

        /* Add these new styles */
        .streak-indicator {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            animation: pulse 2s infinite;
        }

        .streak-fire {
            color: #ff6b6b;
            animation: flame 1.5s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        @keyframes flame {
            0% { transform: scale(1) rotate(0deg); }
            50% { transform: scale(1.2) rotate(5deg); }
            100% { transform: scale(1) rotate(0deg); }
        }

        .progress-circle {
            position: relative;
            width: 60px;
            height: 60px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }

        .progress-circle svg {
            transform: rotate(-90deg);
        }

        .progress-circle circle {
            fill: none;
            stroke-width: 4;
            stroke-linecap: round;
        }

        .progress-circle .progress-bg {
            stroke: #e9ecef;
        }

        .progress-circle .progress-fill {
            stroke: #2196f3;
            transition: stroke-dashoffset 0.5s ease;
        }

        .progress-value {
            position: absolute;
            font-size: 1.2rem;
            font-weight: bold;
            color: #2196f3;
        }

        /* Add these styles in the <style> section */
        .dropdown-menu {
            background: white;
            border: none;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            padding: 0.5rem;
        }

        .dropdown-item {
            padding: 0.75rem 1rem;
            border-radius: 8px;
            color: #333;
            transition: all 0.2s ease;
        }

        .dropdown-item:hover {
            background: #f0f7ff;
            color: #2196f3;
            transform: translateX(5px);
        }

        .dropdown-divider {
            margin: 0.5rem 0;
            border-color: #eee;
        }

        .badge {
            font-size: 0.7em;
            padding: 0.35em 0.65em;
            font-weight: 500;
        }

        .dropdown-item.active, 
        .dropdown-item:active {
            background-color: #2196f3;
            color: white;
        }

        /* Style for the logout button to look like a link */
        .dropdown-item[type="submit"] {
            width: 100%;
            text-align: left;
            background: none;
            border: none;
            cursor: pointer;
        }

        .dropdown-item[type="submit"]:hover {
            background: #ffebee;
            color: #f44336;
        }

        .marketing-points li {
            font-size: 1.1rem;
            color: #666;
        }

        .marketing-points i {
            color: #2196f3;
        }

        .stat-item {
            background: white;
            padding: 1.5rem;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease;
        }

        .stat-item:hover {
            transform: translateY(-5px);
        }

        .stat-item h4 {
            color: #2196f3;
            font-size: 2rem;
            margin: 0.5rem 0;
        }

        .stat-item p {
            color: #666;
            margin: 0;
        }

        .modal-content {
            border: none;
            border-radius: 15px;
            box-shadow: 0 5px 25px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
            border-bottom: 1px solid #eee;
            padding: 1.5rem;
        }

        .modal-body {
            padding: 2rem;
        }

        .modal-footer {
            border-top: 1px solid #eee;
            padding: 1.5rem;
        }

        .course-info-content {
            opacity: 0;
            transform: translateY(20px);
            animation: slideIn 0.5s ease forwards;
        }

        @keyframes slideIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .course-preview img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .start-course-btn {
            padding: 0.75rem 2rem;
            font-size: 1.1rem;
            border-radius: 50px;
        }

        .course-card {
            background: white;
            border-radius: 12px;
            padding: 1.2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            height: 100%;
        }

        .course-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .course-header {
            margin-bottom: 1rem;
            display: flex;
            align-items: center;
        }

        .course-header h4 {
            margin: 0;
            color: #2196f3;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 1.2rem;
        }

        .popular-badge {
            background: linear-gradient(45deg, #FF4500, #FF8C00);
            color: white;
            font-size: 0.65em;
            padding: 0.25em 0.5em;
            border-radius: 15px;
            font-weight: 500;
            text-transform: uppercase;
            animation: glow 2s infinite;
        }

        @keyframes glow {
            0% { box-shadow: 0 0 5px rgba(255, 69, 0, 0.5); }
            50% { box-shadow: 0 0 20px rgba(255, 69, 0, 0.8); }
            100% { box-shadow: 0 0 5px rgba(255, 69, 0, 0.5); }
        }

        .course-details {
            display: flex;
            flex-direction: column;
            gap: 0.6rem;
        }

        .detail-item {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            color: #555;
            font-size: 0.95rem;
        }

        .detail-item i {
            width: 20px;
            text-align: center;
            font-size: 1.1rem;
        }

        /* Color-coded icons */
        .detail-item:nth-child(1) i {
            color: #4CAF50; /* Green for Topics */
        }
        .detail-item:nth-child(2) i {
            color: #E91E63; /* Pink for Clinical Cases */
        }
        .detail-item:nth-child(3) i {
            color: #9C27B0; /* Purple for Questions */
        }
        .detail-item:nth-child(4) i {
            color: #FF9800; /* Orange for Time */
        }
        .detail-item:nth-child(5) i {
            color: #2196F3; /* Blue for Learning Outcome */
        }

        /* Enhanced hover effects */
        .detail-item:hover {
            transform: translateX(5px);
            transition: transform 0.2s ease;
        }

        .detail-item:hover i {
            transform: scale(1.2);
            transition: transform 0.2s ease;
        }

        /* Features section spacing */
        .features {
            padding: 40px 0;
        }

        .features h2 {
            color: #2196f3;
            font-weight: 700;
            margin-bottom: 2rem;
            font-size: 2.2rem;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <?php if (isset($component)) { $__componentOriginale533228d1ac5d8517edc118162b2ac49 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale533228d1ac5d8517edc118162b2ac49 = $attributes; } ?>
<?php $component = App\View\Components\LiveUserCounter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('live-user-counter'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\LiveUserCounter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale533228d1ac5d8517edc118162b2ac49)): ?>
<?php $attributes = $__attributesOriginale533228d1ac5d8517edc118162b2ac49; ?>
<?php unset($__attributesOriginale533228d1ac5d8517edc118162b2ac49); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale533228d1ac5d8517edc118162b2ac49)): ?>
<?php $component = $__componentOriginale533228d1ac5d8517edc118162b2ac49; ?>
<?php unset($__componentOriginale533228d1ac5d8517edc118162b2ac49); ?>
<?php endif; ?>
                    </li>
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('register')); ?>">Sign Up</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?>

                                <?php if(Auth::user()->is_admin): ?>
                                    <span class="badge bg-primary ms-1">Admin</span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="<?php echo e(route('courses.index')); ?>"><i class="fas fa-book me-2"></i>My Courses</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route('mistakes.index')); ?>"><i class="fas fa-exclamation-circle me-2"></i>My Mistakes</a></li>
                                <?php if(Auth::user()->is_admin): ?>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-primary" href="<?php echo e(route('add-topic.form')); ?>"><i class="fas fa-plus-circle me-2"></i>Add Topic</a></li>
                                    <li><a class="dropdown-item text-primary" href="<?php echo e(route('add-question.form')); ?>"><i class="fas fa-question-circle me-2"></i>Add Question</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="/settings">
                                    <i class="fas fa-cog me-2"></i>Settings
                                </a></li>
                                <li>
                                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="dropdown-item text-danger"><i class="fas fa-sign-out-alt me-2"></i>Logout</button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Interactive Background -->
    <div class="interactive-bg">
        <div class="floating-elements">
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
            <div class="floating-element"></div>
        </div>
        <div class="connecting-lines">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <div class="pulse-circles">
            <div class="pulse-circle"></div>
            <div class="pulse-circle"></div>
            <div class="pulse-circle"></div>
        </div>
        <div class="gradient-overlay"></div>
        <div class="noise-texture"></div>
    </div>

    <!-- Hero Section -->
    <div class="hero-section">
        <h1>Welcome to MedCapsule</h1>
        <p>Your ultimate study companion for medical topics.</p>
        <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-primary btn-lg">Get Started</a>
    </div>

    <!-- Features Section -->
    <section class="features">
        <div class="container">
            <h2 class="text-center mb-4">Available Courses</h2>
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <?php $__currentLoopData = $courses->take(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-6 mb-4">
                                <div class="course-card">
                                    <div class="course-header">
                                        <h4>
                                            <?php echo e($course->name); ?>

                                            <?php if($course->name === 'Anatomy'): ?>
                                                <span class="popular-badge">Popular</span>
                                            <?php endif; ?>
                                        </h4>
                                    </div>
                                    <div class="course-details">
                                        <div class="detail-item">
                                            <i class="fas fa-book-medical"></i>
                                            <span><?php echo e($course->topics_count); ?> Topics</span>
                                        </div>
                                        <div class="detail-item">
                                            <i class="fas fa-procedures"></i>
                                            <span><?php echo e($course->cases_count); ?> Cases</span>
                                        </div>
                                        <div class="detail-item">
                                            <i class="fas fa-question-circle"></i>
                                            <span><?php echo e($course->total_questions); ?> Questions</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Course Info Modal -->
    <div class="modal fade" id="courseInfoModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="course-info-content">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="course-stats p-4 bg-light rounded mb-4">
                                    <h4>Course Overview</h4>
                                    <div class="stat-item mb-3">
                                        <i class="fas fa-book-open me-2"></i>
                                        <span class="topics-count"></span> Topics
                                    </div>
                                    <div class="stat-item mb-3">
                                        <i class="fas fa-question-circle me-2"></i>
                                        <span class="questions-count"></span> Questions
                                    </div>
                                </div>
                                <div class="course-description"></div>
                            </div>
                            <div class="col-md-6">
                                <div class="course-preview">
                                    <img src="" alt="Course Preview" class="img-fluid rounded">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <a href="#" class="btn btn-primary start-course-btn">Start Learning</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 MedCapsule. All Rights Reserved.</p>
            <p>
                <a href="/about">About</a> | 
                <a href="/contact">Contact</a> | 
                <a href="/faq">FAQ</a> | 
                <a href="/privacy">Privacy Policy</a> |
                <a href="/demo"><strong>Try 40 Free Questions</strong></a>
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

    <script>
        // Add this to your existing JavaScript
        document.addEventListener('DOMContentLoaded', function() {
            // Update progress circle
            const progressCircle = document.querySelector('.progress-fill');
            const progressValue = document.querySelector('.progress-value');
            const progress = 85; // This should come from your backend
            
            const circumference = 2 * Math.PI * 26; // 2πr
            const offset = circumference - (progress / 100) * circumference;
            
            progressCircle.style.strokeDasharray = `${circumference} ${circumference}`;
            progressCircle.style.strokeDashoffset = offset;
            progressValue.textContent = `${progress}%`;

            // Animate streak fire based on streak value
            const streakValue = 12; // This should come from your backend
            const streakFire = document.querySelector('.streak-fire');
            
            if (streakValue > 0) {
                streakFire.style.display = 'inline-block';
                // Adjust animation speed based on streak
                streakFire.style.animationDuration = `${2 - (streakValue * 0.1)}s`;
            } else {
                streakFire.style.display = 'none';
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            const courseModal = new bootstrap.Modal(document.getElementById('courseInfoModal'));
            const viewCourseBtns = document.querySelectorAll('.view-course-btn');

            viewCourseBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const courseId = this.dataset.courseId;
                    const courseName = this.dataset.courseName;
                    const courseDescription = this.dataset.courseDescription;
                    const topicsCount = this.dataset.topicsCount;
                    const questionsCount = this.dataset.questionsCount;

                    // Update modal content
                    document.querySelector('.modal-title').textContent = courseName;
                    document.querySelector('.course-description').textContent = courseDescription;
                    document.querySelector('.topics-count').textContent = topicsCount;
                    document.querySelector('.questions-count').textContent = questionsCount;
                    document.querySelector('.start-course-btn').href = `/courses/${courseId}`;

                    // Show modal with animation
                    courseModal.show();
                });
            });
        });
    </script>
</body>

</html><?php /**PATH /Users/davidgeorge/Documents/Medcapsule/resources/views/home.blade.php ENDPATH**/ ?>