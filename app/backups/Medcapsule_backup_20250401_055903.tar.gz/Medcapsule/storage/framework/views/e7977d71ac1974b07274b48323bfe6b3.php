<div class="live-users">
    <div class="live-indicator">
        <div class="live-dot"></div>
        <div class="ripple"></div>
    </div>
    <div class="counter-content">
        <span class="user-count" data-count="<?php echo e($count); ?>"><?php echo e($count); ?></span>
        <span class="user-text">active now</span>
    </div>
</div>

<style>
.live-users {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    padding: 8px 16px;
    background: rgba(52, 168, 83, 0.1);
    border-radius: 30px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    cursor: pointer;
}

.live-users:hover {
    background: rgba(52, 168, 83, 0.15);
    transform: translateY(-1px);
}

.live-indicator {
    position: relative;
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.live-dot {
    width: 8px;
    height: 8px;
    background: #34A853;
    border-radius: 50%;
    position: relative;
    box-shadow: 0 0 10px rgba(52, 168, 83, 0.5);
    animation: glow 2s ease-in-out infinite;
}

.ripple {
    position: absolute;
    width: 24px;
    height: 24px;
    border-radius: 50%;
    border: 2px solid #34A853;
    animation: ripple 2s cubic-bezier(0.4, 0, 0.2, 1) infinite;
}

.counter-content {
    display: flex;
    align-items: baseline;
    gap: 6px;
}

.user-count {
    font-weight: 600;
    font-size: 1rem;
    color: #34A853;
    transition: all 0.3s ease;
}

.user-text {
    font-size: 0.9rem;
    color: #666;
    font-weight: 500;
}

/* Animations */
@keyframes glow {
    0%, 100% {
        transform: scale(1);
        opacity: 1;
        box-shadow: 0 0 10px rgba(52, 168, 83, 0.5);
    }
    50% {
        transform: scale(1.1);
        opacity: 0.8;
        box-shadow: 0 0 20px rgba(52, 168, 83, 0.8);
    }
}

@keyframes ripple {
    0% {
        transform: scale(0.8);
        opacity: 0.8;
    }
    100% {
        transform: scale(1.5);
        opacity: 0;
    }
}

/* Number change animation */
.user-count.updating {
    animation: numberUpdate 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}

@keyframes numberUpdate {
    0% {
        transform: translateY(0);
        opacity: 1;
    }
    50% {
        transform: translateY(-10px);
        opacity: 0;
    }
    51% {
        transform: translateY(10px);
        opacity: 0;
    }
    100% {
        transform: translateY(0);
        opacity: 1;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const userCount = document.querySelector('.user-count');
    const liveUsers = document.querySelector('.live-users');

    // Add hover effect for the ripple
    liveUsers.addEventListener('mouseenter', function() {
        const ripple = this.querySelector('.ripple');
        ripple.style.animationDuration = '1s';
    });

    liveUsers.addEventListener('mouseleave', function() {
        const ripple = this.querySelector('.ripple');
        ripple.style.animationDuration = '2s';
    });

    // Update counter with animation
    function updateCounter(newCount) {
        if (newCount !== parseInt(userCount.textContent)) {
            userCount.classList.add('updating');
            setTimeout(() => {
                userCount.textContent = newCount;
            }, 250);
            setTimeout(() => {
                userCount.classList.remove('updating');
            }, 500);
        }
    }

    // Fetch updates every 30 seconds
    setInterval(function() {
        fetch('/api/active-users')
            .then(response => response.json())
            .then(data => {
                updateCounter(data.count);
            });
    }, 30000);
});
</script> <?php /**PATH /Users/davidgeorge/Documents/Medcapsule/resources/views/components/live-user-counter.blade.php ENDPATH**/ ?>