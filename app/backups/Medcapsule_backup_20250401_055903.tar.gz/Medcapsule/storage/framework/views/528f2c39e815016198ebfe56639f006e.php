<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Available Courses - MedCapsule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            color: #1a1a1a;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
        }

        .navbar {
            background: rgba(255, 255, 255, 0.95);
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .navbar-brand {
            color: #2196f3;
            font-weight: 700;
            font-size: 1.8rem;
            transition: transform 0.3s ease;
        }

        .navbar-brand:hover {
            transform: translateY(-2px);
        }

        .hero-section {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            padding: 8rem 2rem 4rem;
            text-align: center;
            position: relative;
            margin-bottom: 2rem;
            overflow: hidden;
        }

        .floating-elements {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            pointer-events: none;
        }

        .floating-element {
            position: absolute;
            background: linear-gradient(45deg, rgba(33, 150, 243, 0.15), rgba(33, 150, 243, 0.05));
            border-radius: 50%;
            filter: blur(3px);
            animation: float 20s infinite ease-in-out;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            25% { transform: translate(100px, 50px) rotate(90deg); }
            50% { transform: translate(50px, 100px) rotate(180deg); }
            75% { transform: translate(-50px, 50px) rotate(270deg); }
        }

        .hero-title {
            font-size: 2.5rem;
            font-weight: 700;
            color: #2196f3;
            margin-bottom: 1rem;
            position: relative;
        }

        .courses-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 2rem;
            padding: 2rem;
            max-width: 1400px;
            margin: 0 auto;
        }

        .course-card {
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        .course-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .course-image {
            position: relative;
            height: 250px;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .course-overlay {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 2rem;
            background: linear-gradient(to top, rgba(0, 0, 0, 0.95) 0%, rgba(0, 0, 0, 0.6) 50%, rgba(0, 0, 0, 0.2) 100%);
            z-index: 1;
        }

        .course-title {
            color: white !important;
            font-size: 1.85rem;
            font-weight: 700;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
            letter-spacing: -0.5px;
        }

        .course-info {
            padding: 1rem;
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }

        .course-info form {
            margin: 0;
            width: 100%;
        }

        .course-stats {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .stat-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #4b5563;
            font-size: 0.875rem;
        }

        .stat-item i {
            color: #2196f3;
        }

        .enrolled-users {
            display: flex;
            align-items: center;
        }

        .user-avatar {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 2px solid white;
            background: #e5e7eb;
            margin-left: -8px;
            position: relative;
            background-size: cover;
            background-position: center;
        }

        .user-avatar:first-child {
            margin-left: 0;
        }

        .more-users {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            border: 2px solid white;
            background: #2196f3;
            margin-left: -8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 0.7rem;
            font-weight: 600;
        }

        .progress-container {
            padding: 0 0.5rem;
        }

        .progress-bar {
            height: 6px;
            background: #f3f4f6;
            border-radius: 3px;
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: #2196f3;
            border-radius: 3px;
            transition: width 0.5s ease;
        }

        .action-btn {
            width: 100%;
            padding: 0.75rem;
            border-radius: 8px;
            font-weight: 500;
            font-size: 0.875rem;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            text-decoration: none;
            border: none;
            cursor: pointer;
            background: none;
        }

        .action-btn.continue {
            background: #16a34a;
            color: white;
        }

        .action-btn.continue:hover {
            background: #15803d;
            transform: translateY(-2px);
        }

        .action-btn.continue i {
            color: white;
        }

        .action-btn.enroll {
            background: #f3f4f6;
            color: #6b7280;
            border: 1px solid #e5e7eb;
        }

        .action-btn.enroll:hover {
            background: #e5e7eb;
            transform: translateY(-2px);
        }

        .action-btn.enroll i {
            color: #9ca3af;
        }

        .unlock-alert {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.9);
            background: white;
            padding: 2rem;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            text-align: center;
            opacity: 0;
            visibility: hidden;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            max-width: 400px;
            width: 90%;
        }

        .unlock-alert.show {
            opacity: 1;
            visibility: visible;
            transform: translate(-50%, -50%) scale(1);
        }

        .unlock-alert h3 {
            color: #2196f3;
            margin-bottom: 1rem;
            font-size: 1.5rem;
        }

        .unlock-alert p {
            color: #2c3e50;
            margin-bottom: 1.5rem;
            font-size: 0.95rem;
            line-height: 1.5;
        }

        .contact-info {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 12px;
            margin: 1rem 0;
        }

        .phone-number, .email {
            font-size: 1.1rem;
            color: #34A853;
            font-weight: 600;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .email {
            color: #2196f3;
        }

        .backdrop {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            backdrop-filter: blur(5px);
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 999;
        }

        .backdrop.show {
            opacity: 1;
            visibility: visible;
        }

        .floating-capsule {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 120px;
            height: 240px;
            background: linear-gradient(135deg, rgba(33, 150, 243, 0.2), rgba(33, 150, 243, 0.05));
            border-radius: 60px;
            filter: blur(2px);
            animation: floatCapsule 8s infinite ease-in-out;
            z-index: 0;
        }

        @keyframes floatCapsule {
            0%, 100% { transform: translate(-50%, -50%) rotate(0deg); }
            25% { transform: translate(-45%, -55%) rotate(5deg); }
            75% { transform: translate(-55%, -45%) rotate(-5deg); }
        }

        .course-progress {
            position: absolute;
            top: 1.2rem;
            left: 1.2rem;
            width: 140px;
            height: 6px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 8px;
            overflow: hidden;
            z-index: 2;
            backdrop-filter: blur(4px);
            box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.2);
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, 
                rgba(255, 255, 255, 0.95),
                rgba(255, 255, 255, 0.85)
            );
            border-radius: 8px;
            transition: all 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        .progress-fill::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(
                90deg,
                rgba(255, 255, 255, 0) 0%,
                rgba(255, 255, 255, 0.4) 50%,
                rgba(255, 255, 255, 0) 100%
            );
            animation: shimmer 2s infinite;
            transform: translateX(-100%);
        }

        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(
                90deg,
                rgba(255, 255, 255, 0.1) 0%,
                rgba(255, 255, 255, 0.2) 100%
            );
        }

        @keyframes shimmer {
            100% { transform: translateX(100%); }
        }

        .course-card:hover .progress-fill {
            transform: scaleY(1.2);
            box-shadow: 0 2px 6px rgba(255, 255, 255, 0.2);
        }

        .enrolled-text {
            display: none;
        }

        .course-card.anatomy {
            border-left: 4px solid #ff4444;
        }
        .course-card.anatomy .course-title {
            color: #ff4444;
        }

        .course-card.histology {
            border-left: 4px solid #ff66b2;
        }
        .course-card.histology .course-title {
            color: #ff66b2;
        }

        .course-card.physiology {
            border-left: 4px solid #ffeb3b;
        }
        .course-card.physiology .course-title {
            color: #ffeb3b;
            text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2);
        }

        .course-card.biochemistry {
            border-left: 4px solid #9c27b0;
        }
        .course-card.biochemistry .course-title {
            color: #9c27b0;
        }

        .course-card.anatomy .course-title,
        .course-card.histology .course-title,
        .course-card.physiology .course-title,
        .course-card.biochemistry .course-title {
            color: white !important;
        }

        /* Enhanced Milestone Progress Bar Styles */
        .milestone-container {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(255, 255, 255, 0.95);
            padding: 1.5rem 2rem;
            box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.15);
            z-index: 1000;
            transform: translateY(0);
            backdrop-filter: blur(10px);
            border-top: 1px solid rgba(0, 0, 0, 0.1);
        }

        .milestone-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.2rem;
        }

        .milestone-info h3 {
            margin: 0;
            font-size: 1.2rem;
            font-weight: 600;
            color: #2196f3;
            text-shadow: 0 0 20px rgba(33, 150, 243, 0.2);
        }

        .milestone-stats {
            display: flex;
            align-items: baseline;
            gap: 0.5rem;
            margin-top: 0.5rem;
        }

        .correct-count {
            font-size: 1.8rem;
            font-weight: 700;
            color: #16a34a;
            text-shadow: 0 0 15px rgba(22, 163, 74, 0.2);
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .correct-count.updating {
            transform: scale(1.2);
            color: #15803d;
        }

        .goal-count {
            font-size: 1.8rem;
            font-weight: 700;
            color: #2196f3;
            text-shadow: 0 0 15px rgba(33, 150, 243, 0.2);
        }

        .milestone-progress {
            position: relative;
            height: 70px;
            margin-top: 1rem;
        }

        .liquid-progress {
            position: relative;
            height: 50px;
            background: #f0f7ff;
            border-radius: 25px;
            overflow: hidden;
            box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .liquid-progress:hover {
            transform: translateY(-2px);
        }

        .liquid-fill {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            background: linear-gradient(90deg, #2196f3, #64b5f6);
            border-radius: 25px;
            transition: width 1.5s cubic-bezier(0.34, 1.56, 0.64, 1);
            filter: brightness(1.1);
        }

        .liquid-wave {
            position: absolute;
            top: -100%;
            right: -50%;
            width: 200%;
            height: 200%;
            transform-origin: 50% 48%;
            border-radius: 43%;
            background: rgba(255, 255, 255, 0.4);
            animation: wave 8s infinite linear;
        }

        .liquid-wave:nth-child(2) {
            animation-duration: 5s;
            opacity: 0.3;
            background: rgba(255, 255, 255, 0.3);
        }

        .liquid-wave:nth-child(3) {
            animation-duration: 3s;
            opacity: 0.2;
            background: rgba(255, 255, 255, 0.2);
        }

        @keyframes wave {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }

        .milestone-markers {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 20px;
            display: flex;
            justify-content: space-between;
            padding: 0 2%;
        }

        .milestone-marker {
            position: relative;
            transform: translateY(0);
            transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        .milestone-marker:hover {
            transform: translateY(-4px);
        }

        .milestone-marker .marker-dot {
            width: 12px;
            height: 12px;
            background: #fff;
            border: 2px solid #2196f3;
            border-radius: 50%;
            margin: 0 auto;
            transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
            box-shadow: 0 0 0 0 rgba(33, 150, 243, 0.5);
            position: relative;
        }

        .marker-dot.achieved {
            background: #2196f3;
            transform: scale(1.2);
            box-shadow: 0 0 0 4px rgba(33, 150, 243, 0.2);
            animation: pulse 2s infinite;
        }

        .marker-dot.achieved::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: rgba(33, 150, 243, 0.2);
            animation: rippleEffect 1.5s infinite;
        }

        @keyframes rippleEffect {
            0% {
                transform: scale(1);
                opacity: 1;
            }
            100% {
                transform: scale(2.5);
                opacity: 0;
            }
        }

        .marker-label {
            position: absolute;
            top: 100%;
            left: 50%;
            transform: translateX(-50%);
            font-size: 0.85rem;
            color: #666;
            margin-top: 0.5rem;
            font-weight: 500;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .milestone-marker:hover .marker-label {
            color: #2196f3;
            transform: translateX(-50%) scale(1.1);
        }

        .ripple-effect {
            position: absolute;
            border-radius: 50%;
            background: rgba(33, 150, 243, 0.4);
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        }

        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }

        .set-goal-btn {
            background: #f0f7ff;
            color: #2196f3;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
            box-shadow: 0 2px 8px rgba(33, 150, 243, 0.15);
        }

        .set-goal-btn:hover {
            background: #e3f2fd;
            transform: translateY(-2px) scale(1.02);
            box-shadow: 0 4px 12px rgba(33, 150, 243, 0.2);
        }

        .set-goal-btn:active {
            transform: translateY(0) scale(0.98);
        }

        .set-goal-btn i {
            transition: transform 0.3s ease;
        }

        .set-goal-btn:hover i {
            transform: rotate(15deg);
        }

        .milestone-complete {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 2rem;
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            z-index: 1001;
            text-align: center;
            display: none;
        }

        .milestone-complete.show {
            display: block;
            animation: popIn 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        @keyframes popIn {
            0% { transform: translate(-50%, -50%) scale(0.8); opacity: 0; }
            100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
        }

        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background: #2196f3;
            opacity: 0;
            z-index: 1000;
            pointer-events: none;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .profile-circle {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #007bff, #00d4ff);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.2);
        }

        .profile-circle:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
            color: white;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <div class="nav-links">
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(route('mistakes.index')); ?>" class="nav-link">
                        <i class="fas fa-book-medical"></i>
                        Mistakes
                    </a>
                    <a href="<?php echo e(route('profile')); ?>" class="profile-circle">
                        <?php echo e(substr(Auth::user()->name, 0, 1)); ?>

                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="nav-link">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <section class="hero-section">
        <div class="floating-elements">
            <?php for($i = 0; $i < 5; $i++): ?>
                <div class="floating-element" style="
                    width: <?php echo e(rand(100, 300)); ?>px;
                    height: <?php echo e(rand(100, 300)); ?>px;
                    top: <?php echo e(rand(-50, 100)); ?>%;
                    left: <?php echo e(rand(-50, 100)); ?>%;
                    animation-delay: -<?php echo e($i * 5); ?>s;
                "></div>
            <?php endfor; ?>
        </div>
        <div class="floating-capsule"></div>
        <h1 class="hero-title">Medical Courses</h1>
    </section>

    <div class="courses-grid">
        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="course-card <?php echo e(strtolower($course->name)); ?>">
                <div class="course-image" style="background-image: url('<?php echo e($course->image_url); ?>')">
                    <div class="course-overlay">
                        <h3 class="course-title"><?php echo e($course->name); ?></h3>
                    </div>
                </div>
                <div class="course-info">
                    <div class="course-stats">
                        <div class="stat-item">
                            <i class="fas fa-book"></i>
                            <span><?php echo e($course->topics_count); ?> Topics</span>
                        </div>
                        <div class="enrolled-users">
                            <?php $__currentLoopData = $course->students()->take(3)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="user-avatar" style="background-image: url('<?php echo e($student->profile_photo_url ?? 'https://ui-avatars.com/api/?name=' . urlencode($student->name)); ?>')" title="<?php echo e($student->name); ?>"></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($course->enrolled_users_count > 3): ?>
                                <div class="more-users">+<?php echo e($course->enrolled_users_count - 3); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="progress-container">
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: <?php echo e($course->completion_percentage); ?>%"></div>
                        </div>
                    </div>
                    <?php if(auth()->check()): ?>
                        <?php if(Auth::user()->is_admin): ?>
                            <a href="<?php echo e(route('topics.forCourse', $course)); ?>" class="action-btn continue">
                                <i class="fas fa-play"></i>
                                Continue Learning
                            </a>
                        <?php elseif($course->completion_percentage > 0): ?>
                            <a href="<?php echo e(route('topics.forCourse', $course)); ?>" class="action-btn continue">
                                <i class="fas fa-play"></i>
                                Continue Learning
                            </a>
                        <?php elseif($course->is_enrolled): ?>
                            <a href="<?php echo e(route('topics.forCourse', $course)); ?>" class="action-btn continue">
                                <i class="fas fa-check"></i>
                                Start Learning
                            </a>
                        <?php else: ?>
                            <button onclick="showUnlockInstructions()" class="action-btn enroll">
                                <i class="fas fa-lock"></i>
                                Unlock Course
                            </button>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="action-btn enroll">
                            <i class="fas fa-lock"></i>
                            Sign in to Enroll
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="backdrop" id="backdrop" onclick="hideUnlockInstructions()"></div>
    <div class="unlock-alert" id="unlockAlert">
        <h3>Course Access Required</h3>
        <p>This course requires special access. Please contact us to purchase access to our premium medical education content.</p>
        <div class="contact-info">
            <div class="phone-number">
                <i class="fas fa-phone-alt"></i>
                +1 (555) 123-4567
            </div>
            <div class="email mt-2">
                <i class="fas fa-envelope"></i>
                contact@medcapsule.com
            </div>
        </div>
        <p class="mt-3 small text-muted">Our team will assist you with course enrollment and provide pricing information.</p>
        <button class="btn btn-primary mt-3" onclick="hideUnlockInstructions()">Close</button>
    </div>

    <?php if(auth()->guard()->check()): ?>
    <div class="milestone-container">
        <div class="milestone-header">
            <div class="milestone-info">
                <h3>Your Learning Progress</h3>
                <div class="milestone-stats">
                    <span class="correct-count"><?php echo e(Auth::user()->correct_answers_count ?? 0); ?></span>
                    <span class="separator">/</span>
                    <span class="goal-count">25</span>
                    <span class="questions-text">questions solved</span>
                </div>
            </div>
            <button class="set-goal-btn" onclick="openGoalModal()">
                <i class="fas fa-flag"></i>
                Set New Goal
            </button>
        </div>
        <div class="milestone-progress">
            <div class="liquid-progress">
                <div class="liquid-fill" style="width: <?php echo e((Auth::user()->correct_answers_count ?? 0) * 4); ?>%">
                    <div class="liquid-wave"></div>
                    <div class="liquid-wave"></div>
                    <div class="liquid-wave"></div>
                </div>
            </div>
            <div class="milestone-markers">
                <?php for($i = 1; $i <= 5; $i++): ?>
                    <div class="milestone-marker" style="left: <?php echo e($i * 20 - 2); ?>%">
                        <div class="marker-dot <?php echo e((Auth::user()->correct_answers_count ?? 0) >= ($i * 5) ? 'achieved' : ''); ?>"></div>
                        <span class="marker-label"><?php echo e($i * 5); ?></span>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>

    <div class="milestone-complete" id="milestoneComplete">
        <h3>🎉 Milestone Achieved! 🎉</h3>
        <p>Congratulations! You've reached your learning goal of <span class="goal-reached">25</span> questions!</p>
        <p>Would you like to set a new goal?</p>
        <button class="btn btn-primary mt-3" onclick="openGoalModal()">Set New Goal</button>
        <button class="btn btn-secondary mt-3 ms-2" onclick="closeMilestoneComplete()">Continue Learning</button>
    </div>

    <!-- Add audio elements -->
    <audio id="milestoneSound" preload="auto">
        <source src="<?php echo e(asset('sounds/milestone.mp3')); ?>" type="audio/mpeg">
        <source src="<?php echo e(asset('sounds/milestone.ogg')); ?>" type="audio/ogg">
    </audio>
    <audio id="correctSound" preload="auto">
        <source src="<?php echo e(asset('sounds/correct.mp3')); ?>" type="audio/mpeg">
        <source src="<?php echo e(asset('sounds/correct.ogg')); ?>" type="audio/ogg">
    </audio>
    <?php endif; ?>

    <!-- Goal Setting Modal -->
    <div class="modal fade" id="goalModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Set Your Learning Goal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="goal-input-container">
                        <label for="goalInput">How many questions would you like to solve?</label>
                        <input type="number" id="goalInput" class="form-control" min="1" max="100" value="20">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-primary" onclick="updateGoal()">Set Goal</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>
    <script>
        function showUnlockInstructions() {
            document.getElementById('unlockAlert').classList.add('show');
            document.getElementById('backdrop').classList.add('show');
        }

        function hideUnlockInstructions() {
            document.getElementById('unlockAlert').classList.remove('show');
            document.getElementById('backdrop').classList.remove('show');
        }

        // Remove the complex card animation and replace with simple hover
        document.querySelectorAll('.course-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-8px)';
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = 'translateY(0)';
            });
        });

        // Initialize goal modal
        const goalModal = new bootstrap.Modal(document.getElementById('goalModal'));

        function openGoalModal() {
            goalModal.show();
        }

        function createConfetti() {
            const colors = ['#2196f3', '#64b5f6', '#1976d2', '#bbdefb', '#16a34a', '#4caf50'];
            const confettiCount = 200;
            const container = document.body;

            for (let i = 0; i < confettiCount; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                
                const color = colors[Math.floor(Math.random() * colors.length)];
                const size = Math.random() * 10 + 5;
                const shape = Math.random() < 0.5 ? '50%' : '0%';
                
                confetti.style.cssText = `
                    width: ${size}px;
                    height: ${size}px;
                    background: ${color};
                    border-radius: ${shape};
                    left: ${Math.random() * 100}vw;
                    top: -20px;
                    opacity: 1;
                    transform: rotate(${Math.random() * 360}deg);
                `;
                
                container.appendChild(confetti);
                
                const animation = confetti.animate([
                    {
                        transform: `translate(0, 0) rotate(0deg)`,
                        opacity: 1
                    },
                    {
                        transform: `translate(${Math.random() * 300 - 150}px, ${window.innerHeight + 100}px) rotate(${Math.random() * 720}deg)`,
                        opacity: 0
                    }
                ], {
                    duration: Math.random() * 2000 + 2000,
                    easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
                });
                
                animation.onfinish = () => confetti.remove();
            }
        }

        function checkMilestoneAchievement(correctCount, goalCount) {
            if (correctCount >= goalCount) {
                document.getElementById('milestoneComplete').classList.add('show');
                createConfetti();
                playMilestoneSound();
                return true;
            }
            return false;
        }

        function playMilestoneSound() {
            const milestoneSound = document.getElementById('milestoneSound');
            milestoneSound.currentTime = 0;
            milestoneSound.play().catch(error => console.log('Sound playback failed:', error));
        }

        function playCorrectSound() {
            const correctSound = document.getElementById('correctSound');
            correctSound.currentTime = 0;
            correctSound.play().catch(error => console.log('Sound playback failed:', error));
        }

        function closeMilestoneComplete() {
            document.getElementById('milestoneComplete').classList.remove('show');
        }

        function updateGoal() {
            const newGoal = document.getElementById('goalInput').value;
            const correctCount = parseInt(document.querySelector('.correct-count').textContent);
            
            document.querySelector('.goal-count').textContent = newGoal;
            document.querySelector('.goal-reached').textContent = newGoal;
            
            // Update progress bar width based on new goal
            const progressPercentage = (correctCount / newGoal) * 100;
            updateProgressBar(progressPercentage);
            
            // Update milestone markers
            const markerInterval = newGoal / 5;
            document.querySelectorAll('.marker-label').forEach((marker, index) => {
                const value = Math.round(markerInterval * (index + 1));
                marker.textContent = value;
                
                // Check if this milestone is achieved
                const dot = marker.previousElementSibling;
                if (correctCount >= value) {
                    if (!dot.classList.contains('achieved')) {
                        dot.classList.add('achieved');
                        createConfetti();
                    }
                } else {
                    dot.classList.remove('achieved');
                }
            });
            
            // Close modals
            goalModal.hide();
            closeMilestoneComplete();
            
            // Check if the new goal is already achieved
            checkMilestoneAchievement(correctCount, newGoal);
        }

        function updateProgressBar(percentage) {
            const liquidFill = document.querySelector('.liquid-fill');
            const correctCount = document.querySelector('.correct-count');
            
            // Add updating class for scale animation
            correctCount.classList.add('updating');
            
            // Animate the liquid fill
            liquidFill.style.width = `${percentage}%`;
            
            // Update milestone markers
            updateMilestoneMarkers();
            
            // Add ripple effect at current progress point
            addRippleEffect(percentage);
            
            // Remove updating class after animation
            setTimeout(() => {
                correctCount.classList.remove('updating');
            }, 400);
        }

        function addRippleEffect(percentage) {
            const progress = document.querySelector('.liquid-progress');
            const ripple = document.createElement('div');
            ripple.className = 'ripple-effect';
            
            // Position the ripple at the current progress point
            const progressWidth = progress.offsetWidth;
            const rippleX = (percentage / 100) * progressWidth;
            
            ripple.style.left = `${rippleX}px`;
            ripple.style.top = '50%';
            
            progress.appendChild(ripple);
            
            // Remove ripple after animation
            setTimeout(() => ripple.remove(), 600);
        }

        function updateMilestoneMarkers() {
            const correctCount = parseInt(document.querySelector('.correct-count').textContent);
            const goalCount = parseInt(document.querySelector('.goal-count').textContent);
            const markerInterval = goalCount / 5;
            
            document.querySelectorAll('.milestone-marker').forEach((marker, index) => {
                const markerValue = markerInterval * (index + 1);
                const dot = marker.querySelector('.marker-dot');
                
                if (correctCount >= markerValue) {
                    if (!dot.classList.contains('achieved')) {
                        dot.classList.add('achieved');
                        // Add celebration effect and play sound when milestone is achieved
                        addMilestoneCelebration(marker);
                        playCorrectSound();
                    }
                } else {
                    dot.classList.remove('achieved');
                }
            });
        }

        function addMilestoneCelebration(marker) {
            // Add particle effects
            for (let i = 0; i < 15; i++) {
                createParticle(marker);
            }
        }

        function createParticle(marker) {
            const particle = document.createElement('div');
            particle.className = 'milestone-particle';
            
            const colors = ['#2196f3', '#64b5f6', '#1976d2', '#bbdefb'];
            const color = colors[Math.floor(Math.random() * colors.length)];
            
            particle.style.cssText = `
                position: absolute;
                width: 6px;
                height: 6px;
                background: ${color};
                border-radius: 50%;
                pointer-events: none;
                z-index: 1000;
            `;
            
            marker.appendChild(particle);
            
            const angle = Math.random() * Math.PI * 2;
            const velocity = 1 + Math.random() * 2;
            const tx = Math.cos(angle) * 50;
            const ty = Math.sin(angle) * 50;
            
            particle.animate([
                { transform: 'translate(0, 0) scale(1)', opacity: 1 },
                { transform: `translate(${tx}px, ${ty}px) scale(0)`, opacity: 0 }
            ], {
                duration: 1000,
                easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
                fill: 'forwards'
            }).onfinish = () => particle.remove();
        }

        function addCelebrationEffect() {
            const container = document.querySelector('.milestone-container');
            const colors = ['#2196f3', '#64b5f6', '#1976d2', '#bbdefb'];
            
            for (let i = 0; i < 30; i++) {
                const particle = document.createElement('div');
                particle.className = 'celebration-particle';
                
                const color = colors[Math.floor(Math.random() * colors.length)];
                const size = Math.random() * 8 + 4;
                
                particle.style.cssText = `
                    position: absolute;
                    width: ${size}px;
                    height: ${size}px;
                    background: ${color};
                    border-radius: 50%;
                    pointer-events: none;
                    z-index: 1000;
                `;
                
                container.appendChild(particle);
                
                const startX = Math.random() * container.offsetWidth;
                const startY = container.offsetHeight;
                const endX = startX + (Math.random() - 0.5) * 200;
                const endY = -50;
                
                particle.animate([
                    { transform: `translate(${startX}px, ${startY}px) scale(0)`, opacity: 0 },
                    { transform: `translate(${startX}px, ${startY * 0.7}px) scale(1)`, opacity: 1 },
                    { transform: `translate(${endX}px, ${endY}px) scale(0)`, opacity: 0 }
                ], {
                    duration: 1000 + Math.random() * 1000,
                    easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
                    fill: 'forwards'
                }).onfinish = () => particle.remove();
            }
        }

        // Initialize milestone markers and check achievement on page load
        document.addEventListener('DOMContentLoaded', () => {
            const correctCount = parseInt(document.querySelector('.correct-count').textContent);
            const goalCount = parseInt(document.querySelector('.goal-count').textContent);
            
            updateMilestoneMarkers();
            checkMilestoneAchievement(correctCount, goalCount);
            
            // Add hover effect for liquid progress
            const liquidProgress = document.querySelector('.liquid-progress');
            liquidProgress.addEventListener('mousemove', (e) => {
                const rect = liquidProgress.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const percentage = (x / rect.width) * 100;
                
                // Add subtle highlight effect
                const highlight = document.createElement('div');
                highlight.className = 'progress-highlight';
                highlight.style.cssText = `
                    position: absolute;
                    width: 30px;
                    height: 100%;
                    background: radial-gradient(circle at center, rgba(255,255,255,0.3) 0%, transparent 70%);
                    pointer-events: none;
                    left: ${x - 15}px;
                    opacity: 0.8;
                `;
                
                liquidProgress.appendChild(highlight);
                setTimeout(() => highlight.remove(), 100);
            });
        });
    </script>
</body>
</html> <?php /**PATH /Users/davidgeorge/Documents/Medcapsule/resources/views/courses.blade.php ENDPATH**/ ?>