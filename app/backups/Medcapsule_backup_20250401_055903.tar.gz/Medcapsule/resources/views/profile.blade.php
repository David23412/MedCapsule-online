<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ Auth::user()->name }} - Profile</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.0/gsap.min.js"></script>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            color: #1a1a1a;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .navbar {
            background-color: rgba(255, 255, 255, 0.95);
            padding: 0.75rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 100;
            backdrop-filter: blur(10px);
        }

        .profile-header {
            background: linear-gradient(135deg, #007bff, #00d4ff);
            padding: 8rem 2rem 4rem;
            color: white;
            text-align: center;
            position: relative;
            overflow: hidden;
            margin-bottom: -3rem;
        }

        .profile-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" fill="rgba(255,255,255,0.05)"/></svg>');
            opacity: 0.1;
            animation: backgroundShift 20s linear infinite;
        }

        @keyframes backgroundShift {
            0% { transform: translateX(0) translateY(0); }
            50% { transform: translateX(20px) translateY(-20px); }
            100% { transform: translateX(0) translateY(0); }
        }

        .profile-avatar {
            width: 150px;
            height: 150px;
            background: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 4rem;
            font-weight: 600;
            color: #007bff;
            margin: 0 auto 2rem;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            border: 4px solid rgba(255, 255, 255, 0.3);
            animation: avatarPulse 2s infinite;
            transition: transform 0.3s ease;
            cursor: pointer;
        }

        .profile-avatar:hover {
            transform: scale(1.05) rotate(5deg);
        }

        @keyframes avatarPulse {
            0% { transform: scale(1); box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); }
            50% { transform: scale(1.05); box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3); }
            100% { transform: scale(1); box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2); }
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 2rem;
            padding: 2rem;
            max-width: 1400px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            opacity: 0;
            transform: translateY(20px);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #007bff, #00d4ff);
            transform: scaleX(0);
            transform-origin: left;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .stat-card:hover::before {
            transform: scaleX(1);
        }

        .stat-card h3 {
            color: #007bff;
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            position: relative;
        }

        .stat-card h3 i {
            transition: transform 0.3s ease;
        }

        .stat-card:hover h3 i {
            transform: scale(1.2) rotate(5deg);
        }

        .streak-counter {
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);
            color: white;
            padding: 2rem;
            border-radius: 16px;
            text-align: center;
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
        }

        .streak-counter:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 30px rgba(255, 107, 107, 0.3);
        }

        .streak-counter::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            animation: shine 2s infinite;
        }

        @keyframes shine {
            from { transform: translateX(-100%); }
            to { transform: translateX(100%); }
        }

        .streak-number {
            font-size: 4rem;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
            margin-bottom: 0.5rem;
            animation: countUp 2s ease-out;
        }

        @keyframes countUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .streak-label {
            font-size: 1.2rem;
            opacity: 0.9;
            position: relative;
        }

        .streak-label::after {
            content: '🔥';
            position: absolute;
            right: -25px;
            top: 50%;
            transform: translateY(-50%);
            animation: flame 0.8s infinite;
        }

        @keyframes flame {
            0%, 100% { transform: translateY(-50%) rotate(-5deg); }
            50% { transform: translateY(-50%) rotate(5deg); }
        }

        .performance-chart {
            width: 100%;
            height: 300px;
            margin-top: 1rem;
            position: relative;
        }

        .performance-chart canvas {
            transition: all 0.3s ease;
        }

        .performance-chart:hover canvas {
            transform: scale(1.02);
        }

        .leaderboard {
            margin-top: 2rem;
        }

        .leaderboard-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            padding: 1rem;
            background: white;
            border-radius: 12px;
            margin-bottom: 0.75rem;
            transition: all 0.3s ease;
            transform: translateX(-20px);
            opacity: 0;
            animation: slideIn 0.5s ease forwards;
        }

        .leaderboard-item:hover {
            transform: translateX(5px);
            background: #f8f9fa;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        @keyframes slideIn {
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        .rank {
            width: 40px;
            height: 40px;
            background: #007bff;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }

        .rank-1 { 
            background: linear-gradient(135deg, #ffd700, #ffa000);
            box-shadow: 0 4px 15px rgba(255, 215, 0, 0.3);
        }
        .rank-2 { 
            background: linear-gradient(135deg, #c0c0c0, #a0a0a0);
            box-shadow: 0 4px 15px rgba(192, 192, 192, 0.3);
        }
        .rank-3 { 
            background: linear-gradient(135deg, #cd7f32, #a05a20);
            box-shadow: 0 4px 15px rgba(205, 127, 50, 0.3);
        }

        .leaderboard-item:hover .rank {
            transform: scale(1.1) rotate(360deg);
        }

        .user-info {
            flex: 1;
        }

        .user-info strong {
            display: block;
            color: #2c3e50;
            margin-bottom: 0.25rem;
        }

        .user-info div {
            color: #6c757d;
            font-size: 0.9rem;
        }

        .time-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .time-stat {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 12px;
            text-align: center;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .time-stat::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent, rgba(0, 123, 255, 0.1), transparent);
            transform: translateX(-100%);
            transition: transform 0.5s ease;
        }

        .time-stat:hover::before {
            transform: translateX(100%);
        }

        .time-stat:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .time-stat h4 {
            font-size: 2rem;
            color: #007bff;
            margin: 0;
            font-weight: 700;
            transition: all 0.3s ease;
        }

        .time-stat:hover h4 {
            transform: scale(1.1);
        }

        .time-stat p {
            color: #666;
            margin: 0.5rem 0 0;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .topic-weakness {
            background: linear-gradient(135deg, #fff5f5, #ffe3e3);
            border-left: 4px solid #ff6b6b;
            padding: 1.5rem;
            border-radius: 12px;
            margin-top: 1.5rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .topic-weakness:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.2);
        }

        .topic-weakness i {
            color: #ff6b6b;
            margin-right: 0.5rem;
            animation: bounce 1s infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-5px); }
        }

        @media (max-width: 768px) {
            .stats-grid {
                grid-template-columns: 1fr;
                padding: 1rem;
            }

            .profile-header {
                padding: 6rem 1rem 3rem;
            }

            .profile-avatar {
                width: 120px;
                height: 120px;
                font-size: 3rem;
            }

            .streak-number {
                font-size: 3rem;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <a href="javascript:history.back()" class="back-button">
                <i class="fas fa-arrow-left"></i>
                Back
            </a>
        </div>
    </nav>

    <div class="profile-header">
        <div class="profile-avatar">
            {{ substr(Auth::user()->name, 0, 1) }}
        </div>
        <h1>{{ Auth::user()->name }}</h1>
        <p>Member since {{ Auth::user()->created_at->format('F Y') }}</p>
    </div>

    <div class="stats-grid">
        <!-- Streak Counter -->
        <div class="stat-card">
            <div class="streak-counter">
                <div class="streak-number">{{ $dayStreak ?? 0 }}</div>
                <div class="streak-label">Day Streak</div>
            </div>
        </div>

        <!-- Performance Overview -->
        <div class="stat-card">
            <h3><i class="fas fa-chart-line"></i> Performance Overview</h3>
            <canvas id="performanceChart" class="performance-chart"></canvas>
        </div>

        <!-- Quick Stats -->
        <div class="stat-card">
            <h3><i class="fas fa-star"></i> Achievement Stats</h3>
            <div class="time-stats">
                <div class="time-stat">
                    <h4>{{ $totalCorrect ?? 0 }}</h4>
                    <p>Correct Answers</p>
                </div>
                <div class="time-stat">
                    <h4>{{ $totalSolved ?? 0 }}</h4>
                    <p>Questions Solved</p>
                </div>
                <div class="time-stat">
                    <h4>{{ $timeSpent ?? '0h' }}</h4>
                    <p>Time Spent</p>
                </div>
            </div>
            @if($weakestTopic ?? false)
                <div class="topic-weakness">
                    <i class="fas fa-exclamation-triangle"></i>
                    <strong>Focus Area:</strong> {{ $weakestTopic }}
                    <br>
                    <small>Keep practicing to improve in this topic!</small>
                </div>
            @endif
        </div>

        <!-- Leaderboard -->
        <div class="stat-card">
            <h3><i class="fas fa-trophy"></i> Top Performers</h3>
            <div class="leaderboard">
                @foreach($topUsers ?? [] as $index => $user)
                    <div class="leaderboard-item" style="animation-delay: {{ $index * 0.1 }}s">
                        <div class="rank rank-{{ $index + 1 }}">{{ $index + 1 }}</div>
                        <div class="user-info">
                            <strong>{{ $user->name }}</strong>
                            <div>{{ $user->correct_answers_count ?? 0 }} correct answers</div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <script>
        // Initialize GSAP
        gsap.from(".stat-card", {
            duration: 0.8,
            opacity: 0,
            y: 50,
            stagger: 0.2,
            ease: "power3.out"
        });

        // Performance Chart
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const gradient = ctx.createLinearGradient(0, 0, 0, 300);
        gradient.addColorStop(0, 'rgba(0, 123, 255, 0.5)');
        gradient.addColorStop(1, 'rgba(0, 123, 255, 0)');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                datasets: [{
                    label: 'Correct Answers',
                    data: {{ json_encode($weeklyPerformance ?? [0, 0, 0, 0, 0, 0, 0]) }},
                    borderColor: '#007bff',
                    borderWidth: 3,
                    tension: 0.4,
                    fill: true,
                    backgroundColor: gradient,
                    pointBackgroundColor: '#007bff',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 6,
                    pointHoverRadius: 8,
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#007bff',
                    pointHoverBorderWidth: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(255, 255, 255, 0.9)',
                        titleColor: '#007bff',
                        titleFont: {
                            size: 14,
                            weight: 'bold',
                            family: "'Poppins', sans-serif"
                        },
                        bodyColor: '#666',
                        bodyFont: {
                            size: 13,
                            family: "'Poppins', sans-serif"
                        },
                        padding: 12,
                        boxPadding: 6,
                        usePointStyle: true,
                        borderColor: '#e9ecef',
                        borderWidth: 1
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            display: true,
                            color: 'rgba(0, 0, 0, 0.05)',
                            drawBorder: false
                        },
                        ticks: {
                            font: {
                                family: "'Poppins', sans-serif"
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            font: {
                                family: "'Poppins', sans-serif"
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                animation: {
                    duration: 2000,
                    easing: 'easeInOutQuart'
                }
            }
        });

        // Add hover effects to stat cards
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                gsap.to(card, {
                    duration: 0.3,
                    y: -5,
                    boxShadow: '0 8px 25px rgba(0, 0, 0, 0.15)',
                    ease: 'power2.out'
                });
            });

            card.addEventListener('mouseleave', () => {
                gsap.to(card, {
                    duration: 0.3,
                    y: 0,
                    boxShadow: '0 4px 15px rgba(0, 0, 0, 0.1)',
                    ease: 'power2.out'
                });
            });
        });
    </script>
</body>
</html> 