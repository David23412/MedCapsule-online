<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $topic->name ?? 'Quiz' }}</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.95);
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            width: 100%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0;
        }

        .navbar-brand {
            color: #007bff;
            font-weight: 700;
            font-size: 1.5rem;
            text-decoration: none;
            display: flex;
            align-items: center;
            transition: transform 0.3s ease;
        }

        .navbar-brand:hover {
            color: #0056b3;
            transform: translateY(-1px);
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .nav-link {
            color: #495057;
            text-decoration: none;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 6px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link i {
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: #007bff;
            background-color: #f8f9fa;
            transform: translateY(-1px);
        }

        .nav-link:hover i {
            transform: scale(1.1);
        }

        .mistakes-link {
            background: linear-gradient(135deg, #fff5f5, #ffe3e3);
            color: #e03131;
            border: 1px solid #ffa8a8;
        }

        .mistakes-link:hover {
            background: linear-gradient(135deg, #ffe3e3, #ffa8a8);
            color: #c92a2a;
            border-color: #ff6b6b;
        }

        .mistakes-link i {
            color: #e03131;
        }

        .mistakes-link:hover i {
            animation: pulse 1s infinite;
        }

        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .main-content {
            margin-top: 80px;
            padding: 2rem;
        }

        .container {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            max-width: 800px;
            margin: 0 auto;
        }

        h1 {
            text-align: center;
            margin-bottom: 2rem;
            color: #2c3e50;
            font-weight: 600;
        }

        .question-box {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            border: 1px solid #e9ecef;
            transition: all 0.3s ease;
        }

        .question-title {
            font-weight: 500;
            color: #2c3e50;
            margin-bottom: 1rem;
        }

        .form-check {
            margin-bottom: 0.5rem;
        }

        .form-check label {
            display: block;
            padding: 1rem;
            border: 2px solid #e9ecef;
            border-radius: 8px;
            background-color: white;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: left;
            color: #495057;
            position: relative;
            overflow: hidden;
        }

        .form-check input {
            display: none;
        }

        .form-check label:hover:not(.correct):not(.incorrect) {
            border-color: #007bff;
            background-color: #f8f9fa;
        }

        .form-check input:checked + label:not(.correct):not(.incorrect) {
            background-color: #e3f2fd;
            border-color: #007bff;
            color: #007bff;
        }

        .form-check label.correct {
            background-color: #e3fcef;
            border-color: #00a854;
            color: #00a854;
            animation: correctAnswer 0.5s ease-out;
        }

        .form-check label.incorrect {
            background-color: #fff1f0;
            border-color: #f5222d;
            color: #f5222d;
            animation: incorrectAnswer 0.5s ease-out;
        }

        @keyframes correctAnswer {
            0% { transform: scale(1); }
            50% { transform: scale(1.02); }
            100% { transform: scale(1); }
        }

        @keyframes incorrectAnswer {
            0% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            75% { transform: translateX(5px); }
            100% { transform: translateX(0); }
        }

        @keyframes wrongX {
            0% { transform: scale(0.8); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }

        @keyframes redGlow {
            0% { box-shadow: 0 0 5px #ff0000; }
            50% { box-shadow: 0 0 30px #ff0000; }
            100% { box-shadow: 0 0 5px #ff0000; }
        }

        .wrong-x {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 150px;
            color: #ff0000;
            z-index: 1001;
            pointer-events: none;
            animation: wrongX 0.5s ease-out;
        }

        .wrong-glow {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 0, 0, 0.05);
            z-index: 1000;
        }

        .submit-btn {
            width: 100%;
            background: #007bff;
            color: white;
            padding: 1rem;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            font-weight: 500;
            cursor: pointer;
            margin-top: 2rem;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .submit-btn:hover:not(:disabled) {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.2);
        }

        .submit-btn:disabled {
            background: #adb5bd;
            cursor: not-allowed;
        }

        .submit-btn::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(
                90deg,
                transparent,
                rgba(255, 255, 255, 0.2),
                transparent
            );
            transition: 0.5s;
        }

        .submit-btn:hover::before {
            left: 100%;
        }

        .popup-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            display: none;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            backdrop-filter: blur(5px);
        }

        .popup {
            background: white;
            padding: 2.5rem;
            border-radius: 20px;
            text-align: center;
            max-width: 600px;
            width: 90%;
            position: relative;
            transform: translateY(20px);
            opacity: 0;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .popup.show {
            transform: translateY(0);
            opacity: 1;
        }

        .popup-title {
            font-size: 2.5rem;
            color: #2c3e50;
            margin-bottom: 1.5rem;
            font-weight: 700;
            animation: slideDown 0.5s ease-out;
        }

        .score-container {
            background: linear-gradient(135deg, #f8f9fa, #e9ecef);
            padding: 2rem;
            border-radius: 16px;
            margin: 1.5rem 0;
            position: relative;
            overflow: hidden;
        }

        .score-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(45deg, transparent, rgba(255,255,255,0.8), transparent);
            transform: translateX(-100%);
            animation: shimmer 2s infinite;
        }

        .popup-score {
            font-size: 4rem;
            font-weight: 800;
            color: #007bff;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0, 123, 255, 0.2);
            animation: scaleIn 0.5s ease-out;
        }

        .score-details {
            font-size: 1.2rem;
            color: #6c757d;
            margin-top: 0.5rem;
            animation: fadeIn 0.5s ease-out 0.2s both;
        }

        .popup-message {
            color: #495057;
            font-size: 1.2rem;
            margin: 1.5rem 0;
            line-height: 1.6;
            animation: fadeIn 0.5s ease-out 0.4s both;
        }

        .popup-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 2rem;
            animation: fadeIn 0.5s ease-out 0.6s both;
        }

        .popup-btn {
            padding: 1rem 2rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            text-decoration: none;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .review-btn {
            background: #f8f9fa;
            color: #495057;
        }

        .review-btn:hover {
            background: #e9ecef;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
        }

        .retry-btn {
            background: #007bff;
            color: white;
        }

        .retry-btn:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 123, 255, 0.2);
        }

        .view-progress-btn {
            background: #28a745;
            color: white;
        }

        .view-progress-btn:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(40, 167, 69, 0.2);
        }

        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes scaleIn {
            from { transform: scale(0.8); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes shimmer {
            100% { transform: translateX(100%); }
        }

        .grade-icon {
            font-size: 3rem;
            margin-bottom: 1rem;
            animation: bounce 1s ease infinite;
        }

        @keyframes bounce {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-10px); }
        }

        .profile-circle {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #007bff, #00d4ff);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.2);
        }

        .profile-circle:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
            color: white;
        }

        @media (max-width: 768px) {
            .container {
                padding: 1rem;
            }

            .popup {
                width: 95%;
                padding: 1.5rem;
            }

            .popup-score {
                font-size: 3rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <div class="nav-links">
                <a href="{{ route('add-question.form') }}" class="nav-link">
                    <i class="fas fa-plus-circle"></i>
                    Add Question
                </a>
                <a href="{{ route('mistakes.index') }}" class="nav-link mistakes-link">
                    <i class="fas fa-book-medical"></i>
                    Mistakes
                </a>
                <a href="javascript:history.back()" class="nav-link">← Back</a>
                <a href="/" class="nav-link">Home</a>
                <a href="{{ route('profile') }}" class="profile-circle">
                    {{ substr(Auth::user()->name, 0, 1) }}
                </a>
            </div>
        </div>
    </nav>

    <div class="main-content">
        <div class="container">
            <h1>{{ $topic->name ?? 'Quiz' }}</h1>

            @if ($questions->isNotEmpty())
                <form id="quiz-form" action="{{ route('quiz.submit', $topic->id) }}" method="POST">
                    @csrf

                    @foreach($questions as $index => $question)
                        <div class="question-box" id="question-{{ $question->id }}">
                            <p class="question-title">{{ $index + 1 }}) {{ $question->question }}</p>

                            <div class="form-check">
                                <input type="radio" name="answers[{{ $question->id }}]" value="A" id="q-{{ $question->id }}-A">
                                <label for="q-{{ $question->id }}-A">A) {{ $question->option_a }}</label>
                            </div>
                            <div class="form-check">
                                <input type="radio" name="answers[{{ $question->id }}]" value="B" id="q-{{ $question->id }}-B">
                                <label for="q-{{ $question->id }}-B">B) {{ $question->option_b }}</label>
                            </div>
                            <div class="form-check">
                                <input type="radio" name="answers[{{ $question->id }}]" value="C" id="q-{{ $question->id }}-C">
                                <label for="q-{{ $question->id }}-C">C) {{ $question->option_c }}</label>
                            </div>
                            <div class="form-check">
                                <input type="radio" name="answers[{{ $question->id }}]" value="D" id="q-{{ $question->id }}-D">
                                <label for="q-{{ $question->id }}-D">D) {{ $question->option_d }}</label>
                            </div>
                        </div>
                    @endforeach

                    <button type="submit" id="submit-btn" class="submit-btn" disabled>Submit Quiz</button>
                </form>
            @else
                <p class="text-center text-danger">No questions available for this topic.</p>
            @endif
        </div>
    </div>

    <!-- Quiz Results Popup -->
    <div class="popup-overlay" id="popup-overlay">
        <div class="popup" id="popup">
            <div class="grade-icon" id="grade-icon"></div>
            <h2 class="popup-title" id="popup-title">Quiz Complete!</h2>
            <div class="score-container">
                <div class="popup-score" id="popup-score">0/0</div>
                <div class="score-details" id="score-details"></div>
            </div>
            <p class="popup-message" id="popup-message">Keep practicing! You're getting there!</p>
            <div class="popup-buttons">
                <button class="popup-btn review-btn" id="review-btn">
                    <i class="fas fa-search"></i>
                    Review Answers
                </button>
                <button class="popup-btn retry-btn" id="retry-btn">
                    <i class="fas fa-redo"></i>
                    Retry Quiz
                </button>
                <a href="{{ route('topics.forCourse', ['course' => $topic->course_id]) }}" class="popup-btn view-progress-btn" id="view-progress-btn">
                    <i class="fas fa-chart-line"></i>
                    View Progress
                </a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js"></script>

    <!-- Add audio elements -->
    <audio id="quizPerfectSound" preload="auto">
        <source src="{{ asset('sounds/quiz-perfect.mp3') }}" type="audio/mpeg">
    </audio>
    <audio id="quizPartialSound" preload="auto">
        <source src="{{ asset('sounds/quiz-partial.mp3') }}" type="audio/mpeg">
    </audio>
    <audio id="quizWrongSound" preload="auto">
        <source src="{{ asset('sounds/quiz-wrong.mp3') }}" type="audio/mpeg">
    </audio>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const quizForm = document.getElementById("quiz-form");
            const submitButton = document.getElementById("submit-btn");
            const popupOverlay = document.getElementById("popup-overlay");
            const popup = document.getElementById("popup");
            const popupTitle = document.getElementById("popup-title");
            const popupScore = document.getElementById("popup-score");
            const popupMessage = document.getElementById("popup-message");
            const reviewButton = document.getElementById("review-btn");
            const retryButton = document.getElementById("retry-btn");
            const viewProgressButton = document.getElementById("view-progress-btn");

            let selectedAnswers = {};

            if (quizForm) {
                document.querySelectorAll('.form-check input').forEach(input => {
                    input.addEventListener('change', function() {
                        selectedAnswers[this.name] = this.value;
                        submitButton.disabled = Object.keys(selectedAnswers).length !== {{ $questions->count() }};
                    });
                });

                quizForm.addEventListener("submit", function (event) {
                    event.preventDefault();

                    // Disable submit button to prevent double submission
                    submitButton.disabled = true;

                    // Create FormData object
                    let formData = new FormData(quizForm);

                    // Log the form data being sent
                    console.log('Submitting quiz with data:', Object.fromEntries(formData));

                    // Send the quiz submission
                    fetch(quizForm.action, {
                        method: "POST",
                        body: formData,
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute("content"),
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        credentials: 'same-origin'
                    })
                    .then(response => {
                        console.log('Response status:', response.status);
                        return response.json().then(data => {
                            if (!response.ok) {
                                throw new Error(data.error || 'Network response was not ok');
                            }
                            return data;
                        });
                    })
                    .then(data => {
                        console.log('Received data:', data);
                        if (data.error) {
                            console.error("Error from server:", data.error);
                            alert("An error occurred: " + data.error);
                            submitButton.disabled = false;
                            return;
                        }

                        // Disable all inputs
                        document.querySelectorAll('.form-check input').forEach(input => {
                            input.disabled = true;
                        });

                        // Show correct/incorrect answers
                        Object.entries(data.correct_answers).forEach(([questionId, correctAnswer]) => {
                            const questionBox = document.getElementById(`question-${questionId}`);
                            const selectedInput = questionBox.querySelector(`input[name="answers[${questionId}]"]:checked`);
                            const correctInput = questionBox.querySelector(`input[value="${correctAnswer}"]`);
                            
                            if (selectedInput) {
                                if (selectedInput.value === correctAnswer) {
                                    selectedInput.nextElementSibling.classList.add('correct');
                                } else {
                                    selectedInput.nextElementSibling.classList.add('incorrect');
                                }
                            }
                            if (correctInput && (!selectedInput || selectedInput.value !== correctAnswer)) {
                                correctInput.nextElementSibling.classList.add('correct');
                            }
                        });

                        const percentage = (data.score / data.total) * 100;
                        const gradeIcon = document.getElementById('grade-icon');
                        const scoreDetails = document.getElementById('score-details');

                        // Set grade icon and message based on score
                        if (percentage === 0) {
                            gradeIcon.innerHTML = '<i class="fas fa-times-circle" style="color: #ff0000;"></i>';
                            popupTitle.textContent = "Oops! 😅";
                            popupMessage.textContent = "Every expert was once a beginner!";
                            scoreDetails.textContent = "Your journey begins!";
                        } else if (percentage === 100) {
                            gradeIcon.innerHTML = '<i class="fas fa-trophy" style="color: #ffd700;"></i>';
                            popupTitle.textContent = "Perfect Score! 🎉";
                            popupMessage.textContent = "Outstanding work! You've mastered this topic!";
                            scoreDetails.textContent = "You're crushing it!";
                        } else if (percentage >= 80) {
                            gradeIcon.innerHTML = '<i class="fas fa-star" style="color: #28a745;"></i>';
                            popupTitle.textContent = "Great Job! 🌟";
                            popupMessage.textContent = "Excellent progress! Keep up the great work!";
                            scoreDetails.textContent = "Almost there!";
                        } else if (percentage >= 50) {
                            gradeIcon.innerHTML = '<i class="fas fa-thumbs-up" style="color: #007bff;"></i>';
                            popupTitle.textContent = "Keep Going! 💪";
                            popupMessage.textContent = "Good effort! Every attempt makes you stronger!";
                            scoreDetails.textContent = "Making progress!";
                        } else {
                            gradeIcon.innerHTML = '<i class="fas fa-lightbulb" style="color: #ffc107;"></i>';
                            popupTitle.textContent = "Learning! 💡";
                            popupMessage.textContent = "Keep practicing - you're getting better!";
                            scoreDetails.textContent = "Keep learning!";
                        }

                        popupScore.textContent = `${data.score}/${data.total}`;

                        // Trigger confetti for good scores
                        if (percentage >= 80) {
                            const duration = 3000;
                            const animationEnd = Date.now() + duration;
                            const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

                            function randomInRange(min, max) {
                                return Math.random() * (max - min) + min;
                            }

                            const interval = setInterval(function() {
                                const timeLeft = animationEnd - Date.now();

                                if (timeLeft <= 0) {
                                    return clearInterval(interval);
                                }

                                const particleCount = 50 * (timeLeft / duration);
                                confetti({
                                    ...defaults,
                                    particleCount,
                                    origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
                                });
                                confetti({
                                    ...defaults,
                                    particleCount,
                                    origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
                                });
                            }, 250);
                        }

                        // Show popup
                        popupOverlay.style.display = "flex";
                        setTimeout(() => {
                            popup.classList.add('show');
                        }, 100);

                        // Play the appropriate sound based on score
                        playQuizCompletionSound(data.score, data.total);
                    })
                    .catch((error) => {
                        console.error("Error:", error);
                        alert("An error occurred while grading the quiz. Please try again.");
                        submitButton.disabled = false;
                    });
                });
            }

            // Add event listeners to popup buttons
            reviewButton.addEventListener("click", function () {
                popup.classList.remove('show');
                setTimeout(() => {
                    popupOverlay.style.display = "none";
                }, 300);
            });

            retryButton.addEventListener("click", function () {
                window.location.reload();
            });

            viewProgressButton.addEventListener("click", function () {
                window.location.href = "{{ route('topics.forCourse', ['course' => $topic->course_id]) }}";
            });
        });

        // Function to play quiz completion sound based on score
        function playQuizCompletionSound(score, total) {
            const percentage = (score / total) * 100;
            
            // Get all sound elements
            const perfectSound = document.getElementById('quizPerfectSound');
            const partialSound = document.getElementById('quizPartialSound');
            const wrongSound = document.getElementById('quizWrongSound');
            
            // Reset all sounds to start
            [perfectSound, partialSound, wrongSound].forEach(sound => {
                sound.pause();
                sound.currentTime = 0;
            });

            // Play appropriate sound based on score
            if (percentage === 100) {
                perfectSound.play().catch(e => console.log('Sound play failed:', e));
            } else if (percentage === 0) {
                wrongSound.play().catch(e => console.log('Sound play failed:', e));
            } else {
                partialSound.play().catch(e => console.log('Sound play failed:', e));
            }
        }
    </script>
</body>
</html>
