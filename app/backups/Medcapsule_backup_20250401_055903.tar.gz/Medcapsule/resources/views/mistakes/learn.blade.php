<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Learn Mistakes</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            color: #1a1a1a;
            margin: 0;
            padding: 0;
            min-height: 100vh;
            overflow-x: hidden;
            line-height: 1.6;
        }

        .navbar {
            background-color: white;
            padding: 0.75rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 100;
            height: 60px;
            display: flex;
            align-items: center;
        }

        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0;
            margin: 0 auto;
            height: 100%;
        }

        .navbar-brand {
            color: #007bff;
            font-weight: 600;
            font-size: 1.25rem;
            text-decoration: none;
        }

        .back-button {
            background: none;
            border: none;
            font-size: 1rem;
            color: #495057;
            cursor: pointer;
            padding: 6px 12px;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.2s ease;
            border-radius: 6px;
            text-decoration: none;
        }

        .back-button:hover {
            background-color: rgba(0, 0, 0, 0.05);
            transform: translateX(-5px);
            color: #007bff;
        }

        .profile-circle {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #007bff, #00d4ff);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.2);
        }

        .profile-circle:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
            color: white;
        }

        .nav-group {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .container {
            width: 100%;
            max-width: 1200px;
            margin: 80px auto 20px;
            padding: 2rem;
            display: grid;
            grid-template-columns: 1fr;
            gap: 2rem;
        }

        .difficulty-selector {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 12px 48px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 95%;
            max-width: 800px;
            background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
            border: 2px solid #007bff;
            z-index: 1000;
        }

        .difficulty-title {
            font-size: 2.5em;
            color: #007bff;
            margin-bottom: 30px;
            text-align: center;
            font-weight: 600;
        }

        .difficulty-options {
            display: flex;
            gap: 30px;
            justify-content: center;
            margin-bottom: 30px;
        }

        .difficulty-option {
            padding: 30px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            flex: 1;
            max-width: 400px;
            background: white;
            text-align: center;
        }

        .difficulty-option:hover {
            border-color: #007bff;
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 123, 255, 0.15);
        }

        .difficulty-option.selected {
            border-color: #007bff;
            background-color: #e3f2fd;
            transform: translateY(-4px);
            box-shadow: 0 8px 24px rgba(0, 123, 255, 0.2);
        }

        .difficulty-option h3 {
            margin: 0 0 15px 0;
            color: #007bff;
            font-size: 1.8em;
        }

        .difficulty-option p {
            margin: 0;
            color: #666;
            font-size: 1.1em;
            line-height: 1.5;
        }

        .start-button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 15px 40px;
            border-radius: 12px;
            font-size: 1.2em;
            cursor: pointer;
            transition: all 0.3s ease;
            display: block;
            margin: 0 auto;
            font-weight: 500;
        }

        .start-button:hover:not(:disabled) {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.2);
        }

        .start-button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
        }

        .card {
            background: white;
            border-radius: 16px;
            border: 1px solid #e0e0e0;
            padding: 30px;
            margin: 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            display: none;
        }

        .card.active {
            display: block;
            animation: fadeIn 0.3s ease-out;
        }

        .question {
            font-size: 1.3em;
            color: #2c3e50;
            margin-bottom: 25px;
            line-height: 1.5;
            font-weight: 500;
        }

        .options {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .option {
            padding: 15px 20px;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 1.1em;
            background: white;
            color: #495057;
        }

        .option:hover {
            border-color: #007bff;
            transform: translateX(4px);
            background-color: #f8f9fa;
        }

        .option.selected {
            border-color: #007bff;
            background-color: #e3f2fd;
        }

        .option.correct {
            border-color: #28a745;
            background-color: #e8f5e9;
            color: #28a745;
        }

        .option.incorrect {
            border-color: #dc3545;
            background-color: #fff5f5;
            color: #dc3545;
        }

        .stage-indicator {
            display: flex;
            justify-content: center;
            gap: 8px;
            margin-top: 20px;
        }

        .stage-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: #e0e0e0;
            transition: all 0.3s ease;
        }

        .stage-dot.active {
            background-color: #28a745;
            transform: scale(1.2);
        }

        .stage-dot.completed {
            background-color: #28a745;
        }

        .encouragement-message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 25px 40px;
            border-radius: 16px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
            display: none;
            z-index: 1000;
            text-align: center;
            border: 2px solid #28a745;
        }

        .encouragement-message h2 {
            color: #28a745;
            margin-bottom: 10px;
            font-size: 1.8em;
            font-weight: 600;
        }

        .encouragement-message p {
            color: #495057;
            margin: 0;
            font-size: 1.2em;
        }

        .completion-message {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 12px 48px rgba(0, 0, 0, 0.2);
            text-align: center;
            display: none;
            z-index: 1000;
            max-width: 600px;
            width: 90%;
            border: 2px solid #28a745;
        }

        .completion-message h1 {
            color: #28a745;
            font-size: 2.5em;
            margin-bottom: 20px;
            font-weight: 700;
        }

        .completion-stats {
            display: flex;
            justify-content: center;
            gap: 30px;
            margin: 30px 0;
        }

        .stat-item {
            background: #f8f9fa;
            padding: 20px 30px;
            border-radius: 12px;
            text-align: center;
            min-width: 150px;
        }

        .stat-item h3 {
            color: #007bff;
            font-size: 2.2em;
            margin: 0;
            font-weight: 700;
        }

        .stat-item p {
            color: #666;
            margin: 5px 0 0;
            font-size: 1em;
        }

        .completion-button {
            background: #007bff;
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 12px;
            font-size: 1.1em;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .completion-button:hover {
            background: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.2);
            color: white;
        }

        .difficulty-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            backdrop-filter: blur(5px);
            display: block;
        }

        /* Remove progress dots styles and update progress container */
        .progress-container {
            position: relative;
            width: 100%;
            max-width: 800px;
            background: white;
            padding: 15px 20px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            display: none;
            animation: slideDown 0.5s ease-out;
        }

        .progress-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }

        .progress-title {
            font-size: 1.1rem;
            color: #495057;
            font-weight: 500;
        }

        .progress-text {
            font-size: 1rem;
            color: #6c757d;
        }

        .progress-bar-container {
            height: 10px;
            background: #e9ecef;
            border-radius: 20px;
            overflow: hidden;
            position: relative;
        }

        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #007bff, #00d4ff);
            width: 0;
            transition: width 0.5s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            border-radius: 20px;
        }

        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(
                90deg,
                rgba(255, 255, 255, 0) 0%,
                rgba(255, 255, 255, 0.3) 50%,
                rgba(255, 255, 255, 0) 100%
            );
            animation: shimmer 2s infinite;
        }

        /* Update animations */
        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Add responsive design */
        @media (max-width: 768px) {
            .container {
                padding: 1rem;
                margin-top: 70px;
            }
            
            h1 {
                font-size: 2rem;
            }
            
            .progress-container {
                margin: 15px auto;
                padding: 12px 15px;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <div class="nav-group">
                <a href="javascript:history.back()" class="back-button">
                    <i class="fas fa-arrow-left"></i>
                    Back
                </a>
                <a href="{{ route('profile') }}" class="profile-circle">
                    {{ substr(Auth::user()->name, 0, 1) }}
                </a>
            </div>
        </div>
    </nav>

    <div class="container">
        <h1>Learn Mistakes</h1>

        @if($mistakes->isEmpty())
            <div class="done-message">
                <p>No mistakes to review at the moment! Great job!</p>
                <p>Come back later for more practice.</p>
            </div>
        @else
            <!-- Add progress bar container -->
            <div class="progress-container">
                <div class="progress-header">
                    <div class="progress-title">Learning Progress</div>
                    <div class="progress-text">0 of 0 mastered</div>
                </div>
                <div class="progress-bar-container">
                    <div class="progress-fill"></div>
                </div>
            </div>

            <div class="difficulty-overlay"></div>
            <div class="difficulty-selector">
                <div class="difficulty-title">How do you want to practice?</div>
                <div class="difficulty-options">
                    <div class="difficulty-option" data-mode="quick">
                        <h3>Quick Review</h3>
                        <p>2 attempts needed to master each question</p>
                    </div>
                    <div class="difficulty-option" data-mode="memorize">
                        <h3>Memorize it All</h3>
                        <p>4 attempts to ensure long-term retention</p>
                    </div>
                </div>
                <button class="start-button" disabled>Start Learning</button>
            </div>

            @foreach($mistakes as $index => $mistake)
                <div class="card {{ $index === 0 ? 'active' : '' }}" 
                    data-question-id="{{ $mistake->question_id }}"
                    data-stage="{{ $mistake->stage }}">
                    <div class="question">
                        {{ $mistake->question->question }}
                    </div>
                    
                    <div class="options">
                        @foreach(['A', 'B', 'C', 'D'] as $option)
                            <div class="option" 
                                data-option="{{ $option }}"
                                data-is-correct="{{ $option === $mistake->question->correct_answer }}">
                                {{ $mistake->question->{'option_' . strtolower($option)} }}
                            </div>
                        @endforeach
                    </div>

                    <div class="stage-indicator">
                        @for($i = 0; $i < 3; $i++)
                            <div class="stage-dot {{ $i <= $mistake->stage ? 'active' : '' }} {{ $i < $mistake->stage ? 'completed' : '' }}"></div>
                        @endfor
                    </div>
                </div>
            @endforeach
        @endif
    </div>

    <div class="encouragement-message">
        <h2>Great job! Keep going! 🎉</h2>
        <p>You're making great progress!</p>
    </div>

    <div class="completion-message">
        <h1>🎉 Congratulations! 🎉</h1>
        <p>All mistakes have been mastered! Your dedication to learning is impressive!</p>
        <div class="completion-stats">
            <div class="stat-item">
                <h3 id="totalQuestions">0</h3>
                <p>Questions Mastered</p>
            </div>
            <div class="stat-item">
                <h3 id="correctStreak">0</h3>
                <p>Best Streak</p>
            </div>
        </div>
        <div class="completion-actions">
            <a href="/mistakes" class="completion-button">Back to Mistakes</a>
        </div>
    </div>

    <!-- Add audio element for encouragement sound -->
    <audio id="encouragementSound" preload="auto">
        <source src="{{ asset('sounds/encouragement.mp3') }}" type="audio/mpeg">
    </audio>

    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.5.1/dist/confetti.browser.min.js"></script>
    <script>
        $(document).ready(function() {
            // Set up CSRF token for all AJAX requests
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            let selectedMode = null;
            let maxStages = 4; // Default for quick review
            let correctStreak = 0;
            let masteredCards = 0;

            // Check if there are any cards to review
            const totalCards = $('.card').length;
            if (totalCards === 0) {
                // If no cards, show the done message and return
                $('.done-message').fadeIn();
                return;
            }

            // Only show difficulty selector if there are cards to review
            $('.difficulty-selector').show();
            $('.difficulty-overlay').addClass('active');

            // Handle difficulty selection
            $('.difficulty-option').on('click', function() {
                $('.difficulty-option').removeClass('selected');
                $(this).addClass('selected');
                selectedMode = $(this).data('mode');
                $('.start-button').prop('disabled', false);
                maxStages = selectedMode === 'quick' ? 2 : 4;
            });

            // Handle start button
            $('.start-button').on('click', function() {
                $('.difficulty-selector').fadeOut(300);
                $('.difficulty-overlay').fadeOut(300, function() {
                    $('.progress-container').fadeIn(300);
                    initializeLearning();
                });
            });

            function initializeLearning() {
                // Show progress container
                $('.progress-container').fadeIn();

                // Initialize progress
                updateProgress(0);

                // Handle option selection
                $('.option').on('click', function() {
                    const selectedOption = $(this);
                    const isCorrect = selectedOption.data('is-correct');
                    const currentCard = $('.card.active');
                    
                    // If no active card, something went wrong
                    if (!currentCard.length) {
                        console.error('No active card found');
                        return;
                    }
                    
                    const currentStage = parseInt(currentCard.data('stage'));
                    
                    // Remove selected class from all options
                    currentCard.find('.option').removeClass('selected correct incorrect');
                    
                    // Add selected class to clicked option
                    selectedOption.addClass('selected');
                    
                    // Show correct/incorrect feedback
                    if (isCorrect) {
                        selectedOption.addClass('correct');
                        correctStreak++;
                        if (correctStreak >= 3) {
                            showEncouragement();
                        }
                        // Update stage indicator
                        currentCard.find('.stage-dot').eq(currentStage).addClass('active');
                        currentCard.find('.stage-dot').eq(currentStage).addClass('completed');
                    } else {
                        selectedOption.addClass('incorrect');
                        correctStreak = 0;
                        // Find and highlight the correct answer
                        currentCard.find('.option[data-is-correct="true"]').addClass('correct');
                        // Reset stage indicators
                        currentCard.find('.stage-dot').removeClass('active completed');
                    }
                    
                    // Send the answer to the server immediately
                    const questionId = currentCard.data('question-id');
                    const selectedAnswer = selectedOption.data('option');
                    
                    $.ajax({
                        url: `/mistakes/${questionId}/review`,
                        method: 'POST',
                        data: {
                            rating: isCorrect ? 'good' : 'again',
                            selected_answer: selectedAnswer,
                            mode: selectedMode
                        },
                        success: function(response) {
                            if (!response.success) {
                                console.error('Server returned error:', response.message);
                                alert('An error occurred: ' + response.message);
                                return;
                            }
                            
                            // Update the card's stage data attribute
                            currentCard.data('stage', response.stage);
                            
                            // Update stage indicators
                            currentCard.find('.stage-dot').removeClass('active completed');
                            for (let i = 0; i <= response.stage; i++) {
                                const dot = currentCard.find('.stage-dot').eq(i);
                                dot.addClass('active');
                                if (i < response.stage) {
                                    dot.addClass('completed');
                                }
                            }
                            
                            // Update progress
                            masteredCards = $('.card').filter(function() {
                                return parseInt($(this).data('stage')) === maxStages;
                            }).length;
                            updateProgress(masteredCards);
                            
                            // Fade out current card
                            currentCard.addClass('fade-out');
                            
                            setTimeout(() => {
                                // Find the next non-mastered card
                                let nextCard = currentCard.next('.card');
                                while (nextCard.length && parseInt(nextCard.data('stage')) >= maxStages) {
                                    nextCard = nextCard.next('.card');
                                }

                                // If no next non-mastered card, try finding one from the beginning
                                if (!nextCard.length) {
                                    nextCard = $('.card').first();
                                    while (nextCard.length && parseInt(nextCard.data('stage')) >= maxStages) {
                                        nextCard = nextCard.next('.card');
                                    }
                                }
                                
                                if (nextCard.length) {
                                    currentCard.removeClass('active fade-out');
                                    nextCard.addClass('active');
                                    // Reset the new card's state
                                    nextCard.find('.option').removeClass('selected correct incorrect');
                                } else {
                                    // If no non-mastered cards remain, show completion message
                                    currentCard.removeClass('active fade-out');
                                    showCompletionMessage();
                                }
                            }, 500);

                            // Check if all cards are mastered
                            const remainingCards = $('.card').filter(function() {
                                return parseInt($(this).data('stage')) < maxStages;
                            }).length;
                            
                            if (remainingCards === 0) {
                                showCompletionMessage();
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('Error submitting answer:', error);
                            console.error('Server response:', xhr.responseText);
                            let errorMessage = 'An error occurred. Please try again.';
                            try {
                                const response = JSON.parse(xhr.responseText);
                                if (response.message) {
                                    errorMessage = response.message;
                                }
                            } catch (e) {
                                console.error('Error parsing error response:', e);
                            }
                            alert(errorMessage);
                        }
                    });
                });
            }

            function updateProgress(masteredCards) {
                const totalCards = $('.card').length;
                const progress = (masteredCards / totalCards) * 100;
                
                // Animate progress bar
                $('.progress-fill').css('width', `${progress}%`);
                
                // Update progress text
                $('.progress-text').text(`${masteredCards} of ${totalCards} mastered`);
            }

            function showEncouragement() {
                // Play the encouragement sound
                const encouragementSound = document.getElementById('encouragementSound');
                encouragementSound.currentTime = 0;
                encouragementSound.play().catch(e => console.log('Sound play failed:', e));

                $('.encouragement-message').fadeIn();
                setTimeout(() => {
                    $('.encouragement-message').fadeOut();
                }, 3000);
            }

            function showCompletionMessage() {
                const totalCards = $('.card').length;
                const bestStreak = correctStreak;
                
                $('#totalQuestions').text(totalCards);
                $('#correctStreak').text(bestStreak);
                
                $('.completion-message').fadeIn();
                
                // Trigger confetti
                const duration = 3000;
                const animationEnd = Date.now() + duration;
                const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

                function randomInRange(min, max) {
                    return Math.random() * (max - min) + min;
                }

                const interval = setInterval(function() {
                    const timeLeft = animationEnd - Date.now();

                    if (timeLeft <= 0) {
                        return clearInterval(interval);
                    }

                    const particleCount = 50 * (timeLeft / duration);
                    confetti({
                        ...defaults,
                        particleCount,
                        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
                    });
                    confetti({
                        ...defaults,
                        particleCount,
                        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
                    });
                }, 250);
            }
        });
    </script>

</body>

</html>