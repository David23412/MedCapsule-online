\<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Topic</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white text-center">
                <h3>Add a New Topic</h3>
            </div>
            <div class="card-body">
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <!-- ✅ FIXED: Route updated to 'add-topic' -->
                <form method="POST" action="{{ route('add-topic') }}">
                    @csrf

                    <!-- Course Selection -->
                    <div class="mb-3">
                        <label class="form-label">Select Course:</label>
                        <select name="course_id" class="form-select" required>
                            <option value="" disabled selected>Select a course</option>
                            @foreach($courses as $course)
                                <option value="{{ $course->id }}">{{ $course->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Topic Name Input -->
                    <div class="mb-3">
                        <label class="form-label">Topic Name:</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>

                    <!-- Topic Description Input -->
                    <div class="mb-3">
                        <label class="form-label">Topic Description:</label>
                        <textarea name="description" class="form-control" rows="3"></textarea>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Add Topic</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
