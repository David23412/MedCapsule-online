<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Course Access - MedCapsule Admin</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            padding-top: 2rem;
        }

        .navbar {
            background: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .card-header {
            background: #2196f3;
            color: white;
            border-radius: 15px 15px 0 0 !important;
            padding: 1rem 1.5rem;
            font-weight: 600;
        }

        .form-control {
            border-radius: 8px;
            border: 1px solid #e0e0e0;
            padding: 0.75rem 1rem;
        }

        .form-control:focus {
            box-shadow: 0 0 0 3px rgba(33, 150, 243, 0.2);
            border-color: #2196f3;
        }

        .btn-primary {
            background: #2196f3;
            border: none;
            border-radius: 8px;
            padding: 0.75rem 1.5rem;
            font-weight: 500;
        }

        .btn-primary:hover {
            background: #1976d2;
            transform: translateY(-1px);
        }

        .table {
            margin: 0;
        }

        .table th {
            font-weight: 600;
            color: #2196f3;
            border-bottom-width: 1px;
        }

        .table td {
            vertical-align: middle;
        }

        .badge {
            padding: 0.5em 1em;
            font-weight: 500;
        }

        .alert {
            border-radius: 10px;
            border: none;
        }

        .enrollment-history {
            max-height: 400px;
            overflow-y: auto;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-icon {
            font-size: 2rem;
            margin-bottom: 1rem;
            color: #2196f3;
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: 600;
            color: #2196f3;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: #666;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .warning-stat {
            color: #ff9800;
        }

        .success-stat {
            color: #4caf50;
        }

        .info-stat {
            color: #2196f3;
        }

        .latest-users-table td {
            padding: 1rem;
        }

        .course-stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1rem;
            margin-top: 1rem;
        }

        .course-stat-card {
            background: white;
            border-radius: 12px;
            padding: 1rem;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        .course-name {
            font-weight: 600;
            color: #2196f3;
            margin-bottom: 0.5rem;
        }

        .course-enrolled {
            font-size: 0.9rem;
            color: #666;
        }

        .status-badge {
            padding: 0.25rem 0.75rem;
            border-radius: 15px;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .status-new {
            background: #e3f2fd;
            color: #2196f3;
        }

        .status-active {
            background: #e8f5e9;
            color: #4caf50;
        }

        .status-inactive {
            background: #ffebee;
            color: #f44336;
        }

        .select2-container .select2-selection--single {
            height: 45px;
            border-radius: 8px;
            border: 1px solid #e0e0e0;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 45px;
            padding-left: 15px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 45px;
        }

        .select2-container--default .select2-results__option--highlighted[aria-selected] {
            background-color: #2196f3;
        }

        .select2-dropdown {
            border-color: #e0e0e0;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .select2-search__field {
            border-radius: 4px !important;
            padding: 5px 10px !important;
        }

        .course-stat-card {
            border-left: 4px solid transparent;
            transition: transform 0.2s ease;
        }

        .course-stat-card:hover {
            transform: translateX(5px);
        }

        .course-stat-card.anatomy {
            border-left-color: #ff4444;
        }
        .course-stat-card.anatomy .course-name {
            color: #ff4444;
        }

        .course-stat-card.histology {
            border-left-color: #ff66b2;
        }
        .course-stat-card.histology .course-name {
            color: #ff66b2;
        }

        .course-stat-card.physiology {
            border-left-color: #ffeb3b;
        }
        .course-stat-card.physiology .course-name {
            color: #ffeb3b;
            text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.2);
        }

        .course-stat-card.biochemistry {
            border-left-color: #9c27b0;
        }
        .course-stat-card.biochemistry .course-name {
            color: #9c27b0;
        }

        .select2-container .select2-selection--single {
            height: 50px;
        }

        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 50px;
            padding-left: 20px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 48px;
        }

        .select2-results__option {
            padding: 10px 20px;
            border-bottom: 1px solid #eee;
        }

        .select2-results__option:last-child {
            border-bottom: none;
        }

        .select2-container--default .select2-results__option--highlighted[aria-selected] {
            background-color: #f8f9fa;
            color: #333;
        }

        .select2-container--default .select2-results__option[aria-selected=true] {
            background-color: #e3f2fd;
        }

        .badge.anatomy {
            background-color: #ff4444 !important;
            color: white;
        }

        .badge.histology {
            background-color: #ff66b2 !important;
            color: white;
        }

        .badge.physiology {
            background-color: #ffeb3b !important;
            color: black;
        }

        .badge.biochemistry {
            background-color: #9c27b0 !important;
            color: white;
        }

        /* Add these styles for the user dropdown */
        .user-option {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
        }

        .user-email {
            font-weight: 500;
        }

        .courses-count {
            font-size: 0.85rem;
            color: #666;
            background: #f0f0f0;
            padding: 2px 8px;
            border-radius: 12px;
        }

        .select2-container--default .select2-results__option {
            padding: 8px 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <a class="navbar-brand" href="/">MedCapsule</a>
                <div class="d-flex">
                    <a href="{{ route('courses.index') }}" class="btn btn-outline-primary me-2">
                        <i class="fas fa-arrow-left"></i> Back to Courses
                    </a>
                </div>
            </div>
        </nav>

        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        <!-- Key Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <i class="fas fa-users stat-icon info-stat"></i>
                <div class="stat-value">{{ $stats['total_users'] }}</div>
                <div class="stat-label">Total Users</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-plus stat-icon success-stat"></i>
                <div class="stat-value">{{ $stats['new_users_today'] }}</div>
                <div class="stat-label">New Users Today</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-calendar-week stat-icon info-stat"></i>
                <div class="stat-value">{{ $stats['new_users_this_week'] }}</div>
                <div class="stat-label">New This Week</div>
            </div>
            <div class="stat-card">
                <i class="fas fa-user-clock stat-icon warning-stat"></i>
                <div class="stat-value">{{ $stats['users_without_courses'] }}</div>
                <div class="stat-label">Users Without Courses</div>
            </div>
        </div>

        <div class="row">
            <!-- Enrollment Form -->
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-user-plus me-2"></i> Enroll User in Course
                    </div>
                    <div class="card-body">
                        <form action="{{ route('admin.user-course.enroll') }}" method="POST">
                            @csrf
                            <div class="mb-3">
                                <label for="email" class="form-label">Select User</label>
                                <select class="form-control user-select" id="email" name="email" required>
                                    <option value="">Select or search for a user...</option>
                                    @foreach($users as $user)
                                        <option value="{{ $user->email }}" data-courses="{{ count($user->courses) }}">
                                            {{ $user->email }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="course_id" class="form-label">Select Course</label>
                                <select class="form-select course-select" id="course_id" name="course_id" required>
                                    <option value="">Choose a course...</option>
                                    @foreach($courses as $course)
                                        <option value="{{ $course->id }}">{{ $course->name }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-plus-circle me-2"></i>Add Course Access
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Latest Users -->
                <div class="card mt-4">
                    <div class="card-header">
                        <i class="fas fa-user-clock me-2"></i> Latest Registered Users
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table latest-users-table">
                                <thead>
                                    <tr>
                                        <th>Email</th>
                                        <th>Registered</th>
                                        <th>Courses</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($latestUsers as $user)
                                        <tr>
                                            <td>{{ $user['email'] }}</td>
                                            <td>{{ Carbon\Carbon::parse($user['registered_at'])->diffForHumans() }}</td>
                                            <td>{{ $user['courses_count'] }}</td>
                                            <td>
                                                @if($user['courses_count'] == 0)
                                                    <span class="status-badge status-new">New</span>
                                                @else
                                                    <span class="status-badge status-active">Active</span>
                                                @endif
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <!-- Course Statistics -->
                <div class="card">
                    <div class="card-header">
                        <i class="fas fa-chart-bar me-2"></i> Course Enrollment Statistics
                    </div>
                    <div class="card-body">
                        <div class="course-stats-grid">
                            @foreach($courseStats as $stat)
                                <div class="course-stat-card {{ strtolower(str_replace(' ', '-', $stat['name'])) }}">
                                    <div class="course-name">{{ $stat['name'] }}</div>
                                    <div class="course-enrolled">
                                        <i class="fas fa-users me-2"></i>
                                        {{ $stat['enrolled_count'] }} enrolled
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <!-- Recent Enrollments -->
                <div class="card mt-4">
                    <div class="card-header">
                        <i class="fas fa-history me-2"></i> Recent Enrollments
                    </div>
                    <div class="card-body enrollment-history">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Email</th>
                                        <th>Course</th>
                                        <th>Enrolled On</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($enrolledUsers as $enrollment)
                                        <tr>
                                            <td>{{ $enrollment->email }}</td>
                                            <td>
                                                <span class="badge {{ strtolower($enrollment->course_name) }}">
                                                    {{ $enrollment->course_name }}
                                                </span>
                                            </td>
                                            <td>{{ Carbon\Carbon::parse($enrollment->created_at)->format('M d, Y') }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Select2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            // Enhanced Select2 initialization for user selection
            $('.user-select').select2({
                placeholder: 'Select or search for a user...',
                allowClear: true,
                width: '100%',
                templateResult: formatUser,
                templateSelection: formatUserSelection
            });

            // Enhanced Select2 initialization for course selection
            $('.course-select').select2({
                placeholder: 'Choose a course...',
                allowClear: true,
                width: '100%'
            });

            // Format user options in dropdown
            function formatUser(user) {
                if (!user.id) return user.text;
                
                var $container = $(
                    '<div class="user-option">' +
                        '<div class="user-email">' + user.text + '</div>' +
                        '<span class="courses-count">' + 
                            $(user.element).data('courses') + ' courses' +
                        '</span>' +
                    '</div>'
                );
                
                return $container;
            }

            // Format selected user
            function formatUserSelection(user) {
                if (!user.id) return user.text;
                return user.text;
            }
        });
    </script>
</body>
</html> 