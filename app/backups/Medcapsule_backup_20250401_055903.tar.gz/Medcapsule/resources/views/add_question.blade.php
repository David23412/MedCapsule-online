<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Question</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow"> 
            <div class="card-header bg-primary text-white text-center">
                <h3>Add a New Question</h3>
            </div>
            <div class="card-body">
                @if(session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                @if($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <!-- ✅ FIXED: Route updated to 'add-question' -->
                <form method="POST" action="{{ route('add-question') }}">
                    @csrf

                    <!-- Topic Selection -->
                    <div class="mb-3">
                        <label class="form-label">Topic:</label>
                        <select name="topic_id" class="form-select" required>
                            <option value="" disabled selected>Select a topic</option>
                            @foreach($topics as $topic)
                                <option value="{{ $topic->id }}">{{ $topic->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Question Input -->
                    <div class="mb-3">
                        <label class="form-label">Question:</label>
                        <input type="text" name="question" class="form-control" required>
                    </div>

                    <!-- Answer Options -->
                    <div class="mb-3">
                        <label class="form-label">Option A:</label>
                        <input type="text" name="option_a" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Option B:</label>
                        <input type="text" name="option_b" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Option C:</label>
                        <input type="text" name="option_c" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Option D:</label>
                        <input type="text" name="option_d" class="form-control" required>
                    </div>

                    <!-- Correct Answer Selection -->
                    <div class="mb-3">
                        <label class="form-label">Correct Answer:</label>
                        <select name="correct_answer" class="form-select" required>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-success w-100">Add Question</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>