<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $course->name }} Topics - MedCapsule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: white;
            padding: 1rem 2rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.95);
        }

        .navbar-brand {
            color: #007bff;
            font-weight: 700;
            font-size: 1.5rem;
            text-decoration: none;
        }

        .course-header {
            background: linear-gradient(135deg, #007bff, #00bcd4);
            color: white;
            padding: 6rem 2rem 4rem;
            text-align: center;
            margin-bottom: 2rem;
            position: relative;
            overflow: hidden;
        }

        .course-header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: url('data:image/svg+xml,<svg width="20" height="20" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><rect width="1" height="1" fill="rgba(255,255,255,0.05)"/></svg>');
            opacity: 0.1;
        }

        .course-title {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 0.8rem;
        }

        .course-description {
            font-size: 1rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto 1.5rem;
        }

        .topics-container {
            max-width: 1000px;
            margin: 0 auto;
            padding: 2rem;
        }

        .topic-card {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            animation: slideIn 0.5s ease-out forwards;
            opacity: 0;
            transform: translateY(20px);
            position: relative;
            overflow: hidden;
        }

        .topic-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
        }

        .topic-info {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1.5rem;
        }

        .topic-main {
            flex: 1;
            padding-right: 2rem;
        }

        .topic-name {
            font-size: 1.4rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 0.8rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
        }

        .topic-name i {
            color: #007bff;
            font-size: 1rem;
        }

        .topic-description {
            color: #6c757d;
            font-size: 1rem;
            margin-bottom: 1.2rem;
            line-height: 1.6;
        }

        .topic-stats {
            display: flex;
            align-items: center;
            gap: 2rem;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 1px solid #eee;
        }

        .stat-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #6c757d;
            font-size: 0.9rem;
        }

        .progress-container {
            flex: 1;
            margin-top: 1.5rem;
        }

        .progress {
            height: 10px;
            background-color: #e9ecef;
            border-radius: 5px;
            overflow: hidden;
            margin-bottom: 0.8rem;
        }

        .progress-bar {
            height: 100%;
            border-radius: 5px;
            transition: width 1.5s cubic-bezier(0.4, 0, 0.2, 1);
            background: linear-gradient(90deg, #007bff, #00bcd4);
            position: relative;
        }

        .progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(90deg, 
                rgba(255,255,255,0) 0%, 
                rgba(255,255,255,0.3) 50%, 
                rgba(255,255,255,0) 100%);
            animation: shimmer 2s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .progress-label {
            display: flex;
            justify-content: space-between;
            color: #6c757d;
            font-size: 0.8rem;
            font-weight: 500;
        }

        .start-quiz-btn {
            background: #007bff;
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 8px;
            font-weight: 500;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
            margin-top: 1rem;
        }

        .start-quiz-btn:hover {
            background: #0056b3;
            transform: translateX(2px);
            color: white;
        }

        .start-quiz-btn i {
            transition: transform 0.3s ease;
        }

        .start-quiz-btn:hover i {
            transform: translateX(3px);
        }

        .grade-badge {
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
        }

        .grade-mastered {
            background-color: #e3fcef;
            color: #00a854;
        }

        .grade-good {
            background-color: #fff7e6;
            color: #fa8c16;
        }

        .grade-bad {
            background-color: #fff1f0;
            color: #f5222d;
        }

        .grade-none {
            background-color: #f5f5f5;
            color: #8c8c8c;
        }

        @keyframes slideIn {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .topic-card:nth-child(1) { animation-delay: 0.1s; }
        .topic-card:nth-child(2) { animation-delay: 0.2s; }
        .topic-card:nth-child(3) { animation-delay: 0.3s; }
        .topic-card:nth-child(4) { animation-delay: 0.4s; }
        .topic-card:nth-child(5) { animation-delay: 0.5s; }

        .nav-link {
            color: #495057;
            text-decoration: none;
            margin-left: 1.5rem;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .nav-link:hover {
            color: #007bff;
        }

        .nav-links {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .profile-circle {
            width: 40px;
            height: 40px;
            background: linear-gradient(135deg, #007bff, #00d4ff);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            text-decoration: none;
            transition: all 0.3s ease;
            box-shadow: 0 2px 8px rgba(0, 123, 255, 0.2);
        }

        .profile-circle:hover {
            transform: scale(1.1);
            box-shadow: 0 4px 12px rgba(0, 123, 255, 0.3);
            color: white;
        }

        .mistakes-link {
            color: #dc3545;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            background: rgba(220, 53, 69, 0.1);
            transition: all 0.3s ease;
        }

        .mistakes-link:hover {
            background: rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }

        .course-progress {
            background: rgba(255, 255, 255, 0.15);
            padding: 1.5rem 2rem;
            border-radius: 16px;
            margin-top: 1.5rem;
            display: inline-flex;
            align-items: center;
            gap: 2rem;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .course-progress:hover {
            transform: translateY(-2px);
            background: rgba(255, 255, 255, 0.2);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }

        .progress-circle {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            font-weight: 700;
            position: relative;
            transition: all 0.3s ease;
        }

        .progress-circle::before {
            content: '';
            position: absolute;
            top: -3px;
            left: -3px;
            right: -3px;
            bottom: -3px;
            border-radius: 50%;
            border: 3px solid rgba(255, 255, 255, 0.2);
            animation: pulseRing 2s infinite;
        }

        .progress-circle::after {
            content: '';
            position: absolute;
            top: -2px;
            left: -2px;
            right: -2px;
            bottom: -2px;
            border-radius: 50%;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            animation: spin 1s linear infinite;
        }

        @keyframes pulseRing {
            0% {
                transform: scale(1);
                opacity: 0.6;
            }
            50% {
                transform: scale(1.1);
                opacity: 0.3;
            }
            100% {
                transform: scale(1);
                opacity: 0.6;
            }
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        .course-progress:hover .progress-circle {
            transform: scale(1.05);
            background: rgba(255, 255, 255, 0.15);
        }

        .progress-text {
            text-align: left;
            transition: all 0.3s ease;
        }

        .progress-text-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 0.3rem;
            color: white;
        }

        .progress-text-subtitle {
            font-size: 1rem;
            opacity: 0.9;
            font-weight: 500;
        }

        .course-progress:hover .progress-text-subtitle {
            opacity: 1;
        }

        .empty-state {
            text-align: center;
            padding: 3rem;
            color: #6c757d;
        }

        .empty-state i {
            font-size: 4rem;
            margin-bottom: 1rem;
            color: #dee2e6;
        }

        .last-attempt {
            font-size: 0.9rem;
            color: #6c757d;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .last-attempt i {
            color: #007bff;
        }

        .topic-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="container">
            <a class="navbar-brand" href="/">MedCapsule</a>
            <div class="nav-links">
                <a href="{{ route('courses.index') }}" class="nav-link">
                    <i class="fas fa-arrow-left"></i>
                    Back to Courses
                </a>
                <a href="{{ route('mistakes.index') }}" class="mistakes-link">
                    <i class="fas fa-times-circle"></i>
                    View Mistakes
                </a>
                <a href="{{ route('profile') }}" class="profile-circle">
                    {{ substr(Auth::user()->name, 0, 1) }}
                </a>
            </div>
        </div>
    </nav>

    <!-- Course Header -->
    <header class="course-header">
        <h1 class="course-title">{{ $course->name }}</h1>
        <p class="course-description">{{ $course->description }}</p>
        <div class="course-progress">
            <div class="progress-circle">
                {{ $topics->where('percentage_grade', '>=', 80)->count() }}/{{ $topics->count() }}
            </div>
            <div class="progress-text">
                <div class="progress-text-title">Course Progress</div>
                <div class="progress-text-subtitle">Topics Mastered</div>
            </div>
        </div>
    </header>

    <!-- Topics List -->
    <div class="topics-container">
        @if($topics->count() > 0)
            @foreach($topics as $topic)
                <div class="topic-card">
                    <div class="topic-info">
                        <div class="topic-main">
                            <h3 class="topic-name">
                                <i class="fas fa-book-open"></i>
                                {{ $topic->name }}
                            </h3>
                            <p class="topic-description">{{ $topic->description }}</p>
                            
                            @if($topic->last_attempt_date)
                                <div class="last-attempt">
                                    <i class="far fa-clock"></i>
                                    Last attempt: {{ \Carbon\Carbon::parse($topic->last_attempt_date)->diffForHumans() }}
                                </div>
                            @endif
                        </div>
                        
                        @if($topic->percentage_grade !== null)
                            <div class="grade-badge 
                                {{ $topic->percentage_grade >= 80 ? 'grade-mastered' : 
                                   ($topic->percentage_grade >= 50 ? 'grade-good' : 'grade-bad') }}">
                                <i class="fas {{ $topic->percentage_grade >= 80 ? 'fa-star' : 
                                               ($topic->percentage_grade >= 50 ? 'fa-check' : 'fa-times') }}"></i>
                                {{ $topic->percentage_grade >= 80 ? 'Mastered' : 
                                   ($topic->percentage_grade >= 50 ? 'Good' : 'Bad') }}
                            </div>
                        @else
                            <div class="grade-badge grade-none">
                                <i class="fas fa-hourglass-start"></i>
                                Not Started
                            </div>
                        @endif
                    </div>

                    <div class="progress-container">
                        <div class="progress">
                            <div class="progress-bar" style="width: {{ $topic->percentage_grade ?? 0 }}%"></div>
                        </div>
                        <div class="progress-label">
                            <span>Progress</span>
                            <span>{{ $topic->percentage_grade ? number_format($topic->percentage_grade, 1) : 0 }}%</span>
                        </div>
                    </div>

                    <div class="topic-actions">
                        <div class="stat-item">
                            @if($topic->percentage_grade >= 80)
                                <i class="fas fa-check-circle text-success"></i>
                                Mastered
                            @elseif($topic->percentage_grade !== null)
                                <i class="fas fa-sync text-warning"></i>
                                Keep practicing
                            @else
                                <i class="fas fa-flag text-primary"></i>
                                Ready to start
                            @endif
                        </div>
                        
                        <a href="{{ route('quiz.start', ['course' => $course->id, 'topic' => $topic->id]) }}" class="start-quiz-btn" onclick="event.preventDefault(); window.location.href='{{ route('quiz.start', ['course' => $course->id, 'topic' => $topic->id]) }}';">
                            @if($topic->percentage_grade !== null)
                                Retake Quiz
                            @else
                                Start Quiz
                            @endif
                            <i class="fas fa-arrow-right"></i>
                        </a>
                    </div>
                </div>
            @endforeach
        @else
            <div class="empty-state">
                <i class="fas fa-book-open"></i>
                <h3>No Topics Available</h3>
                <p>Topics for this course will be added soon.</p>
            </div>
        @endif
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Prevent any interference with the Start Quiz button
        document.addEventListener('DOMContentLoaded', function() {
            const quizButtons = document.querySelectorAll('.start-quiz-btn');
            quizButtons.forEach(button => {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    window.location.href = this.getAttribute('href');
                });
            });
        });
    </script>
</body>
</html>