<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    CourseController,
    TopicController,
    QuestionController,
    QuizController,
    MistakeController,
    LearnController,
    SettingsController,
    HomeController,
    UserCourseController,
    ProfileController
};
use Illuminate\Support\Facades\DB;

// Public routes
Route::get('/', [HomeController::class, 'index'])->name('home');

// Protected routes (require authentication)
Route::middleware(['auth'])->group(function () {
    // Course Routes
    Route::get('/courses', [CourseController::class, 'index'])->name('courses.index');
    Route::get('/courses/{course}', [CourseController::class, 'show'])->name('courses.show');
    Route::post('/courses/{course}/enroll', [CourseController::class, 'enroll'])->name('courses.enroll');

    // Topic Routes
    Route::get('/courses/{course}/topics', [TopicController::class, 'forCourse'])->name('topics.forCourse');
    
    // Cases Routes (new)
    Route::get('/courses/{course}/cases', [TopicController::class, 'casesForCourse'])->name('cases.forCourse');
    Route::get('/courses/{course}/cases-count', [TopicController::class, 'casesCount'])->name('cases.count');

    // Quiz Routes
    Route::get('/courses/{course}/topics/{topic}/quiz', [QuizController::class, 'startQuiz'])->name('quiz.start');
    Route::post('/quiz/{topic}/submit', [QuizController::class, 'gradeQuiz'])->name('quiz.submit');
    Route::get('/quiz/result', [QuizController::class, 'result'])->name('quiz.result');

    // Mistakes Page Route
    Route::get('/mistakes', [MistakeController::class, 'index'])->name('mistakes.index');
    Route::delete('/mistakes/{questionId}', [MistakeController::class, 'destroy'])->name('mistakes.destroy');
    Route::delete('/mistakes/{question_id}/remove', [MistakeController::class, 'removeMistake']);
    Route::get('/mistakes/learn', [LearnController::class, 'learnMistakes'])->name('mistakes.learn');
    Route::post('/mistakes/{questionId}/review', [LearnController::class, 'reviewMistake'])->name('mistakes.review');

    // Settings routes
    Route::get('/settings', [SettingsController::class, 'index'])->name('settings.index');
    Route::post('/settings/update', [SettingsController::class, 'update'])->name('settings.update');

    // Dashboard route
    Route::get('/dashboard', function () {
        return redirect('/courses');
    })->name('dashboard');

    // Admin Routes - Protected
    Route::middleware([\App\Http\Middleware\AdminMiddleware::class])->group(function () {
        // Topic Management
        Route::get('/add-topic', [TopicController::class, 'showAddTopicForm'])->name('add-topic.form');
        Route::post('/add-topic', [TopicController::class, 'addTopic'])->name('add-topic');

        // Question Management
        Route::get('/add-question', [QuestionController::class, 'showAddQuestionForm'])->name('add-question.form');
        Route::post('/add-question', [QuestionController::class, 'storeQuestion'])->name('add-question');

        // User Course Management
        Route::get('/manage-access', [UserCourseController::class, 'index'])->name('admin.user-course');
        Route::post('/manage-access/enroll', [UserCourseController::class, 'enroll'])->name('admin.user-course.enroll');
        Route::get('/manage-access/search-users', [UserCourseController::class, 'searchUsers'])->name('admin.user-course.search');
    });

    // Profile route
    Route::get('/profile', [ProfileController::class, 'index'])->name('profile');
});

// Include authentication routes
require __DIR__.'/auth.php';

// Add this with your other routes
Route::get('/api/active-users', function() {
    $count = DB::table('visitors')
        ->where('last_active_at', '>=', now()->subMinutes(5))
        ->count();
    return response()->json(['count' => $count]);
});
