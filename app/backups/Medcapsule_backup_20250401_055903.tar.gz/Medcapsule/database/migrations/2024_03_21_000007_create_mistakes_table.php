<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('mistakes', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->foreignId('question_id')->constrained()->onDelete('cascade');
            $table->string('submitted_answer');
            $table->timestamp('last_attempt_date')->useCurrent();
            $table->integer('stage')->default(0);
            $table->integer('interval')->default(1); // Days until next review
            $table->decimal('ease_factor', 4, 2)->default(2.5); // Ease factor for interval calculation
            $table->timestamp('next_review_date')->nullable(); // When to review next
            $table->integer('consecutive_correct')->default(0); // Number of consecutive correct answers
            $table->integer('times_reviewed')->default(0); // Total number of times reviewed

            $table->primary(['user_id', 'question_id']); // Composite primary key
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('mistakes');
    }
};
