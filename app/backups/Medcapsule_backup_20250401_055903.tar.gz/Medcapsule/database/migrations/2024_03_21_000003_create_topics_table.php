<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('topics', function (Blueprint $table) {
            $table->id(); // Auto-incrementing ID
            $table->string('name'); // Topic name
            $table->foreignId('course_id')->nullable()->constrained()->nullOnDelete(); // Keeps topics even if the course is deleted
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('topics');
    }
};