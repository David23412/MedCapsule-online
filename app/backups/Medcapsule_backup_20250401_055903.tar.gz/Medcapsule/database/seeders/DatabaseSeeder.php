<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            AdminSeeder::class,    // Run this first to ensure admin exists
            CourseSeeder::class,   // Then create courses
            TopicSeeder::class,    // Then topics
            QuestionSeeder::class  // Finally questions
        ]);
    }
}