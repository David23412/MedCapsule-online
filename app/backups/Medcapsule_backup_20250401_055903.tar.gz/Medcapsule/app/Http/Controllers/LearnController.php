<?php

namespace App\Http\Controllers;

use App\Models\Mistake;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class LearnController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the mistakes that need to be reviewed.
     */
    public function learnMistakes()
    {
        try {
            $userId = auth()->id();
            Log::info('Starting learnMistakes for user', ['user_id' => $userId]);

            // Get mistakes for the user that are not mastered (stage < 2 for quick review)
            $mistakes = Mistake::where('user_id', $userId)
                ->with('question')
                ->where('stage', '<', 2)  // Only get non-mastered questions
                ->orderBy('last_attempt_date', 'desc')
                ->get();

            Log::info('Fetched mistakes for user', [
                'user_id' => $userId,
                'mistake_count' => $mistakes->count()
            ]);

            // If there are no mistakes to learn, redirect back to mistakes page with success message
            if ($mistakes->isEmpty()) {
                return redirect()->route('mistakes.index')
                    ->with('success', '🎉 Congratulations! All mistakes have been mastered!');
            }

            return view('mistakes.learn', compact('mistakes'));
        } catch (\Exception $e) {
            Log::error('Error in learnMistakes', [
                'user_id' => $userId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return redirect()->route('mistakes.index')->with('error', 'An error occurred while loading the learn page.');
        }
    }

    /**
     * Get updated list of mistakes after a review
     */
    public function getUpdatedMistakes(Request $request)
    {
        $userId = auth()->id();

        $mistakes = Mistake::where('user_id', $userId)
            ->where(function($query) {
                $query->whereNull('next_review_date')
                      ->orWhere('next_review_date', '<=', now());
            })
            ->with('question')
            ->orderBy('next_review_date', 'asc')
            ->get();

        return response()->json([
            'success' => true,
            'mistakes_count' => $mistakes->count(),
            'has_mistakes' => $mistakes->isNotEmpty()
        ]);
    }

    /**
     * Handle the review (rating) for a mistake.
     */
    public function reviewMistake(Request $request, $questionId)
    {
        try {
            $userId = auth()->id();
            
            Log::info('📌 Starting review process', [
                'question_id' => $questionId,
                'user_id' => $userId,
                'rating' => $request->input('rating'),
                'selected_answer' => $request->input('selected_answer'),
                'mode' => $request->input('mode')
            ]);
            
            DB::beginTransaction();

            // Find the mistake by user_id and question_id
            $mistake = Mistake::where('user_id', $userId)
                ->where('question_id', $questionId)
                ->first();

            if (!$mistake) {
                Log::error('❌ Mistake not found', [
                    'question_id' => $questionId,
                    'user_id' => $userId
                ]);
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Mistake not found'
                ], 404);
            }

            $rating = $request->input('rating');  // 'again' or 'good'
            $selectedAnswer = $request->input('selected_answer');
            $mode = $request->input('mode');  // 'quick' or 'memorize'

            if (!$rating || !$selectedAnswer || !$mode) {
                Log::error('❌ Missing required data', [
                    'rating' => $rating,
                    'selected_answer' => $selectedAnswer,
                    'mode' => $mode
                ]);
                DB::rollBack();
                return response()->json([
                    'success' => false,
                    'message' => 'Missing required data: rating, selected_answer, and mode are required'
                ], 400);
            }

            // Set max stages based on mode
            $maxStages = $mode === 'quick' ? 2 : 4;  // 2 attempts for quick review, 4 for memorization

            Log::info('📌 Processing review for mistake', [
                'question_id' => $questionId,
                'user_id' => $userId,
                'rating' => $rating,
                'selected_answer' => $selectedAnswer,
                'mode' => $mode,
                'current_stage' => $mistake->stage,
                'max_stages' => $maxStages
            ]);

            // Update the mistake's stage based on the rating
            if ($rating === 'good') {
                $mistake->stage = min($mistake->stage + 1, $maxStages);
                $mistake->consecutive_correct++;
                $mistake->interval = $mistake->consecutive_correct === 1 ? 1 : 
                    ($mistake->consecutive_correct === 2 ? 6 : 
                    round($mistake->interval * $mistake->ease_factor));
                $mistake->next_review_date = now()->addDays($mistake->interval);
            } else {
                $mistake->stage = 0;  // Reset to beginning
                $mistake->consecutive_correct = 0;
                $mistake->interval = 1;
                $mistake->next_review_date = now()->addDay();
            }

            $mistake->last_attempt_date = now();
            $mistake->times_reviewed++;
            $mistake->save();

            // Check if the mistake is mastered
            $isMastered = $mistake->stage >= $maxStages;

            // If mastered, delete the mistake
            if ($isMastered) {
                Log::info('🎉 Mistake mastered, removing from list', [
                    'question_id' => $questionId,
                    'user_id' => $userId,
                    'final_stage' => $mistake->stage
                ]);
                $mistake->delete();
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'stage' => $mistake->stage,
                'is_mastered' => $isMastered
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('❌ Error in reviewMistake', [
                'question_id' => $questionId,
                'user_id' => $userId,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while processing your review: ' . $e->getMessage()
            ], 500);
        }
    }
}