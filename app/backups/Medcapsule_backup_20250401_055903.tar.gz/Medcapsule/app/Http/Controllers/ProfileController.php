<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Mistake;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    public function index()
    {
        $user = Auth::user();
        
        // Calculate day streak
        $dayStreak = $this->calculateDayStreak($user);
        
        // Get total correct answers and solved questions
        $stats = $this->getUserStats($user);
        
        // Get weekly performance data
        $weeklyPerformance = $this->getWeeklyPerformance($user);
        
        // Get weakest topic
        $weakestTopic = $this->getWeakestTopic($user);
        
        // Calculate total time spent
        $timeSpent = $this->calculateTimeSpent($user);
        
        // Get top performers
        $topUsers = $this->getTopPerformers();
        
        return view('profile', compact(
            'dayStreak',
            'weeklyPerformance',
            'weakestTopic',
            'timeSpent',
            'topUsers'
        ))->with($stats);
    }
    
    private function calculateDayStreak($user)
    {
        $dates = Mistake::where('user_id', $user->id)
            ->where('stage', '>', 0)  // Consider stage > 0 as correct
            ->orderBy('last_attempt_date', 'desc')
            ->pluck('last_attempt_date')
            ->map(function ($date) {
                return $date->format('Y-m-d');
            })
            ->unique();
            
        if ($dates->isEmpty()) {
            return 0;
        }
        
        $streak = 0;
        $today = Carbon::today();
        $checkDate = $today->copy();
        
        // Check if user has answered today
        if (!$dates->contains($today->format('Y-m-d'))) {
            $checkDate = $today->subDay();
        }
        
        while ($dates->contains($checkDate->format('Y-m-d'))) {
            $streak++;
            $checkDate->subDay();
        }
        
        return $streak;
    }
    
    private function getUserStats($user)
    {
        $totalCorrect = Mistake::where('user_id', $user->id)
            ->where('stage', '>', 0)  // Consider stage > 0 as correct
            ->count();
            
        $totalSolved = Mistake::where('user_id', $user->id)
            ->count();
            
        return compact('totalCorrect', 'totalSolved');
    }
    
    private function getWeeklyPerformance($user)
    {
        $startOfWeek = Carbon::now()->startOfWeek();
        $endOfWeek = Carbon::now()->endOfWeek();
        
        $dailyCorrect = Mistake::where('user_id', $user->id)
            ->where('stage', '>', 0)  // Consider stage > 0 as correct
            ->whereBetween('last_attempt_date', [$startOfWeek, $endOfWeek])
            ->select(DB::raw('DATE(last_attempt_date) as date'), DB::raw('count(*) as correct_count'))
            ->groupBy('date')
            ->get()
            ->pluck('correct_count', 'date');
            
        $performance = [];
        for ($day = $startOfWeek->copy(); $day <= $endOfWeek; $day->addDay()) {
            $date = $day->format('Y-m-d');
            $performance[] = $dailyCorrect[$date] ?? 0;
        }
        
        return $performance;
    }
    
    private function getWeakestTopic($user)
    {
        return Mistake::where('user_id', $user->id)
            ->join('questions', 'mistakes.question_id', '=', 'questions.id')
            ->join('topics', 'questions.topic_id', '=', 'topics.id')
            ->select('topics.name', DB::raw('AVG(mistakes.stage) as avg_stage'))
            ->groupBy('topics.name')
            ->havingRaw('COUNT(*) >= 5')  // Only consider topics with at least 5 attempts
            ->orderBy('avg_stage', 'asc')
            ->first()
            ?->name;
    }
    
    private function calculateTimeSpent($user)
    {
        // Since we don't have time_spent column, we'll estimate based on attempts
        $totalAttempts = Mistake::where('user_id', $user->id)
            ->count();
            
        // Assume average of 2 minutes per attempt
        $totalMinutes = $totalAttempts * 2;
            
        if ($totalMinutes < 60) {
            return $totalMinutes . 'm';
        }
        
        $hours = floor($totalMinutes / 60);
        $minutes = $totalMinutes % 60;
        
        return $hours . 'h ' . ($minutes > 0 ? $minutes . 'm' : '');
    }
    
    private function getTopPerformers()
    {
        return User::withCount(['mistakes as correct_answers_count' => function ($query) {
                $query->where('stage', '>', 0);  // Consider stage > 0 as correct
            }])
            ->orderBy('correct_answers_count', 'desc')
            ->take(5)
            ->get();
    }
} 