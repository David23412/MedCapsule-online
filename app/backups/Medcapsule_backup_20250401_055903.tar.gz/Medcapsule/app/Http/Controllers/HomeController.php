<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function index()
    {
        $courses = Course::select('courses.*')
            ->selectRaw('(SELECT COUNT(*) FROM topics WHERE topics.course_id = courses.id AND topics.name NOT LIKE "% cases") as topics_count')
            ->selectRaw('(SELECT COUNT(*) FROM topics WHERE topics.course_id = courses.id AND topics.name LIKE "% cases") as cases_count')
            ->selectRaw('(SELECT COUNT(*) FROM questions WHERE questions.topic_id IN (SELECT id FROM topics WHERE topics.course_id = courses.id)) as total_questions')
            ->selectRaw('(SELECT COUNT(*) FROM course_user WHERE course_user.course_id = courses.id) as enrolled_students_count');

        if (auth()->check()) {
            $courses = $courses->addSelect([
                'completion_percentage' => DB::raw("(
                    SELECT COALESCE(AVG(topics.percentage_grade), 0)
                    FROM topics 
                    WHERE topics.course_id = courses.id
                )"),
                'mastered_topics_count' => DB::raw("(
                    SELECT COUNT(*)
                    FROM topics 
                    WHERE topics.course_id = courses.id 
                    AND topics.percentage_grade >= 80
                )")
            ]);
        }

        $courses = $courses->get();

        if (auth()->check()) {
            $courses->each(function($course) {
                $course->completion_percentage = round($course->completion_percentage, 2);
            });
        }
 
        return view('home', compact('courses'));
    }
} 