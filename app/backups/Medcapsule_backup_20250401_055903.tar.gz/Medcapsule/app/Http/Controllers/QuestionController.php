<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\Topic;

class QuestionController extends Controller
{
    public function showAddQuestionForm()
    {
        $topics = Topic::all();
        return view('add_question', compact('topics'));
    }

    public function storeQuestion(Request $request)
    {
        $request->validate([
            'topic_id' => 'required|exists:topics,id',
            'question' => 'required|string',
            'option_a' => 'required|string',
            'option_b' => 'required|string',
            'option_c' => 'required|string',
            'option_d' => 'required|string',
            'correct_answer' => 'required|string|in:A,B,C,D',
        ]);

        Question::create([
            'topic_id' => $request->topic_id,
            'question' => $request->question,
            'option_a' => $request->option_a,
            'option_b' => $request->option_b,
            'option_c' => $request->option_c,
            'option_d' => $request->option_d,
            'correct_answer' => $request->correct_answer,
        ]);

        return redirect()->back()->with('success', 'Question added successfully!');
    }

    public function editQuestion($id)
    {
        $question = Question::findOrFail($id);
        $topics = Topic::all();
        return view('edit_question', compact('question', 'topics'));
    }

    public function updateQuestion(Request $request, $id)
    {
        $request->validate([
            'topic_id' => 'required|exists:topics,id',
            'question_text' => 'required|string',
            'options' => 'required|array|min:4',
            'correct_answer' => 'required|string|in:A,B,C,D',
        ]);

        $question = Question::findOrFail($id);
        $question->update([
            'topic_id' => $request->topic_id,
            'question_text' => $request->question_text,
            'options' => json_encode($request->options),
            'correct_answer' => $request->correct_answer,
        ]);

        return redirect()->back()->with('success', 'Question updated successfully!');
    }

    public function deleteQuestion($id)
    {
        Question::findOrFail($id)->delete();
        return redirect()->back()->with('success', 'Question deleted successfully!');
    }
}