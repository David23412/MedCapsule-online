<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class UserCourseController extends Controller
{
    public function index()
    {
        // Get only non-admin users
        $users = User::where('is_admin', false)
            ->orderBy('email')
            ->get();
            
        $courses = Course::all();
        
        // Get recent enrollments with user details
        $enrolledUsers = DB::table('course_user')
            ->join('users', 'users.id', '=', 'course_user.user_id')
            ->join('courses', 'courses.id', '=', 'course_user.course_id')
            ->select('users.email', 'courses.name as course_name', 'course_user.created_at')
            ->orderBy('course_user.created_at', 'desc')
            ->take(10)
            ->get();

        // Get statistics
        $stats = [
            'total_users' => User::where('is_admin', false)->count(),
            'new_users_today' => User::where('is_admin', false)
                ->whereDate('created_at', Carbon::today())
                ->count(),
            'new_users_this_week' => User::where('is_admin', false)
                ->where('created_at', '>=', Carbon::now()->subWeek())
                ->count(),
            'users_without_courses' => User::where('is_admin', false)
                ->whereDoesntHave('courses')
                ->count()
        ];

        // Get course statistics
        $courseStats = Course::withCount(['students as enrolled_count'])
            ->get()
            ->map(function ($course) {
                return [
                    'id' => $course->id,
                    'name' => $course->name,
                    'enrolled_count' => $course->enrolled_count,
                ];
            });

        // Get latest registered users
        $latestUsers = User::where('is_admin', false)
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get()
            ->map(function ($user) {
                return [
                    'email' => $user->email,
                    'registered_at' => $user->created_at,
                    'courses_count' => $user->courses()->count(),
                ];
            });

        return view('admin.user-course', compact(
            'users', 
            'courses', 
            'enrolledUsers', 
            'stats',
            'courseStats',
            'latestUsers'
        ));
    }

    public function searchUsers(Request $request)
    {
        $query = $request->get('query');
        
        $users = User::where('is_admin', false)
            ->where(function($q) use ($query) {
                $q->where('email', 'like', "%{$query}%")
                  ->orWhere('name', 'like', "%{$query}%");
            })
            ->orderBy('email')
            ->get();

        return response()->json($users);
    }

    public function enroll(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'course_id' => 'required|exists:courses,id'
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return back()->with('error', 'User not found with this email.');
        }

        // Check if user is already enrolled
        if ($user->courses()->where('course_id', $request->course_id)->exists()) {
            return back()->with('error', 'User is already enrolled in this course.');
        }

        // Enroll user in the course
        $user->courses()->attach($request->course_id);

        return back()->with('success', 'User successfully enrolled in the course.');
    }
} 