<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Topic;
use App\Models\Course;
use App\Models\Mistake;
use App\Models\Question;
use Carbon\Carbon;

class TopicController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * ✅ Show topics for a specific course.
     */
    public function forCourse(Course $course)
    {
        // Check if user is enrolled in the course
        if (!auth()->user()->courses->contains($course->id)) {
            return redirect()->route('courses.index')
                ->with('error', 'You must be enrolled in this course to view its topics.');
        }

        // Load the course with its topics
        $course->load(['topics' => function ($query) {
            $query->orderBy('order');
        }]);

        return view('topics_for_course', [
            'course' => $course,
            'topics' => $course->topics
        ]);
    }

    /**
     * ✅ Show the add topic form.
     */
    public function showAddTopicForm()
    {
        $courses = Course::all(); // Fetch all courses
        return view('add_topic', compact('courses'));
    }

    /**
     * ✅ Handle topic creation.
     */
    public function addTopic(Request $request)
    {
        $validated = $request->validate([
            'course_id' => 'required|exists:courses,id',
            'name' => 'required|string|max:255',
            'description' => 'nullable|string'
        ]);

        // Set default order
        $maxOrder = Topic::where('course_id', $validated['course_id'])->max('order') ?? 0;

        $topic = Topic::create([
            'course_id' => $validated['course_id'],
            'name' => $validated['name'],
            'description' => $request->description,
            'order' => $maxOrder + 1
        ]);

        // Update course statistics
        $course = Course::find($validated['course_id']);
        $courseStats = $course->statistics()->firstOrCreate([]);
        
        // Update topics count
        $regularTopicsCount = $course->topics()->where('name', 'not like', '% cases')->count();
        $casesCount = $course->topics()->where('name', 'like', '% cases')->count();
        
        $courseStats->update([
            'topics_count' => $regularTopicsCount,
            'cases_count' => $casesCount
        ]);

        return redirect()->back()->with('success', 'Topic added successfully!');
    }

    /**
     * ✅ Update topic data after quiz attempt.
     */
    public function updateTopicAfterQuiz($topicId)
    {
        $topic = Topic::findOrFail($topicId);

        // Get total number of questions
        $totalQuestions = Question::where('topic_id', $topicId)->count();
        if ($totalQuestions === 0) {
            return;
        }

        // Count mistakes (incorrect answers)
        $incorrectAnswers = Mistake::whereHas('question', function ($query) use ($topicId) {
            $query->where('topic_id', $topicId);
        })->count();

        // Calculate correct answers
        $correctAnswers = $totalQuestions - $incorrectAnswers;

        // Calculate percentage grade
        $percentageGrade = ($correctAnswers / $totalQuestions) * 100;

        // Update topic details
        $topic->update([
            'percentage_grade' => $percentageGrade,
            'last_attempt_date' => Carbon::now(),
        ]);
    }

    public function casesForCourse(Course $course)
    {
        return $course->topics()
            ->where('name', 'like', '% cases')
            ->get();
    }

    public function casesCount(Course $course)
    {
        return $course->topics()
            ->where('name', 'like', '% cases')
            ->count();
    }
}