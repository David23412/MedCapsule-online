<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Question;
use App\Models\Topic;
use App\Models\Mistake;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use App\Models\Course;

class QuizController extends Controller 
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * ✅ Show the quiz for a topic.
     */
    public function startQuiz(Course $course, Topic $topic)
    {
        try {
            Log::info('📌 startQuiz triggered for topic ID: ' . $topic->id);

            // Verify that the topic belongs to the course
            if ($topic->course_id !== $course->id) {
                Log::error('Topic does not belong to course', [
                    'topic_id' => $topic->id,
                    'course_id' => $course->id
                ]);
                return back()->with('error', 'Invalid topic for this course.');
            }

            // Verify that the user is enrolled in the course
            if (!auth()->user()->courses->contains($course->id)) {
                Log::error('User not enrolled in course', [
                    'user_id' => auth()->id(),
                    'course_id' => $course->id
                ]);
                return back()->with('error', 'You must be enrolled in this course to take quizzes.');
            }

            Log::info('✅ Topic found:', ['topic' => $topic->toArray()]);

            // Log all questions in the database
            $allQuestions = Question::all();
            Log::info('📚 All questions in database:', ['count' => $allQuestions->count(), 'questions' => $allQuestions->toArray()]);

            $questions = Question::where('topic_id', $topic->id)->get();
            Log::info('📚 Questions found for topic:', [
                'topic_id' => $topic->id,
                'count' => $questions->count(),
                'questions' => $questions->toArray()
            ]);

            if ($questions->isEmpty()) {
                Log::warning('⚠️ No questions available for topic:', ['topic_id' => $topic->id]);
                return back()->with('error', 'No questions available for this quiz.');
            }

            Log::info('✅ Rendering solve_quiz view with:', [
                'topic' => $topic->toArray(),
                'questions_count' => $questions->count()
            ]);

            return view('solve_quiz', compact('topic', 'questions', 'course'));
        } catch (\Exception $e) {
            Log::error('❌ Error in startQuiz:', [
                'error' => $e->getMessage(),
                'topic_id' => $topic->id,
                'trace' => $e->getTraceAsString()
            ]);
            return back()->with('error', 'An error occurred while loading the quiz.');
        }
    }

    /**
     * ✅ Grade quiz and track mistakes (No attempts stored)
     */
    public function gradeQuiz(Request $request, $topicId)
    {
        try {
            Log::info('📌 gradeQuiz triggered', [
                'request' => $request->all(),
                'topicId' => $topicId
            ]);

            $userId = auth()->id();

            $answers = $request->input('answers', []);
            Log::info('Answers received:', ['answers' => $answers]);

            if (empty($answers)) {
                Log::warning('No answers submitted');
                return response()->json(['error' => 'No answers submitted.'], 400);
            }

            $questions = Question::where('topic_id', $topicId)->get();
            Log::info('Questions found:', ['count' => $questions->count(), 'questions' => $questions->toArray()]);

            $totalQuestions = $questions->count();

            if ($totalQuestions === 0) {
                Log::warning('No questions available for topic', ['topicId' => $topicId]);
                return response()->json(['error' => 'No questions available.'], 400);
            }

            $score = 0;
            $correctAnswers = [];

            DB::beginTransaction();
            try {
                foreach ($questions as $question) {
                    $submittedAnswer = $answers[$question->id] ?? null;
                    $correctAnswers[$question->id] = $question->correct_answer;

                    Log::info('Grading question', [
                        'questionId' => $question->id,
                        'submittedAnswer' => $submittedAnswer,
                        'correctAnswer' => $question->correct_answer
                    ]);

                    if ($submittedAnswer === $question->correct_answer) {
                        $score++;
                        // Increment user's correct answers count
                        $user = auth()->user();
                        $user->increment('correct_answers_count');
                    } else {
                        Log::info('❌ Storing mistake for user ' . $userId . ' on question ' . $question->id);

                        try {
                            // Try to find existing mistake
                            $mistake = Mistake::where('user_id', $userId)
                                ->where('question_id', $question->id)
                                ->first();

                            if ($mistake) {
                                Log::info('Updating existing mistake', [
                                    'userId' => $userId,
                                    'questionId' => $question->id,
                                    'submittedAnswer' => $submittedAnswer
                                ]);

                                // Update existing mistake
                                $mistake->update([
                                    'submitted_answer' => $submittedAnswer,
                                    'last_attempt_date' => now()
                                ]);
                            } else {
                                Log::info('Creating new mistake', [
                                    'userId' => $userId,
                                    'questionId' => $question->id,
                                    'submittedAnswer' => $submittedAnswer
                                ]);

                                // Create new mistake using the model
                                $mistake = Mistake::create([
                                    'user_id' => $userId,
                                    'question_id' => $question->id,
                                    'submitted_answer' => $submittedAnswer,
                                    'last_attempt_date' => now()
                                ]);

                                // Initialize Anki parameters
                                $mistake->initializeAnki();
                                $mistake->save();
                            }
                        } catch (\Exception $e) {
                            Log::error('Error handling mistake:', [
                                'error' => $e->getMessage(),
                                'userId' => $userId,
                                'questionId' => $question->id
                            ]);
                            throw $e;
                        }
                    }
                }

                // Calculate percentage grade
                $percentageGrade = ($score / $totalQuestions) * 100;

                Log::info('Updating topic grade', [
                    'topicId' => $topicId,
                    'percentageGrade' => $percentageGrade,
                    'score' => $score,
                    'totalQuestions' => $totalQuestions
                ]);

                try {
                    // Update the Topic model with the grade and last attempt date
                    $topic = Topic::findOrFail($topicId);
                    $topic->update([
                        'percentage_grade' => $percentageGrade,
                        'last_attempt_date' => now()
                    ]);

                    Log::info('Successfully updated topic grade', [
                        'topic_id' => $topicId,
                        'new_grade' => $percentageGrade,
                        'last_attempt_date' => now()
                    ]);
                } catch (\Exception $e) {
                    Log::error('Failed to update topic grade', [
                        'topic_id' => $topicId,
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString()
                    ]);
                    throw $e;
                }

                DB::commit();

                Log::info('Quiz graded successfully', [
                    'score' => $score,
                    'total' => $totalQuestions,
                    'percentageGrade' => $percentageGrade
                ]);

                return response()->json([
                    'score' => $score,
                    'total' => $totalQuestions,
                    'percentage_grade' => number_format($percentageGrade, 2),
                    'correct_answers' => $correctAnswers
                ]);
            } catch (\Exception $e) {
                DB::rollBack();
                Log::error('❌ Error in gradeQuiz transaction', [
                    'error' => $e->getMessage(),
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'trace' => $e->getTraceAsString()
                ]);
                return response()->json(['error' => 'An error occurred while grading the quiz.'], 500);
            }
        } catch (\Exception $e) {
            Log::error('❌ Error in gradeQuiz', [
                'error' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTraceAsString()
            ]);
            return response()->json(['error' => 'An error occurred while grading the quiz.'], 500);
        }
    }

    /**
     * ✅ Show mistakes (incorrect answers).
     */
    public function showMistakes()
    {
        Log::info('📌 showMistakes triggered');
    
        $userId = 1;
    
        $mistakes = Mistake::where('user_id', $userId)
            ->with('question')
            ->get();
    
        Log::info('🔥 Loaded Mistakes:', $mistakes->toArray()); // Debugging
    
        return view('mistakes', compact('mistakes'));
    }
    
}