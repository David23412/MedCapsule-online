<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;
use Illuminate\Support\Facades\DB;

class CourseController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth')->except(['index', 'show']);
    }

    /**
     * Show all available courses.
     */
    public function showCourses()
    {
        $courses = Course::paginate(6); // Load 6 courses per page
        return view('courses', compact('courses'));
    }

    public function index()
    {
        $courses = Course::withCount(['topics' => function($query) {
                $query->where('name', 'not like', '%cases%');
            }])
            ->withCount(['topics as cases_count' => function($query) {
                $query->where('name', 'like', '%cases%');
            }])
            ->withCount('students as enrolled_users_count')
            ->when(auth()->check(), function($query) {
                return $query->with(['students' => function($query) {
                    $query->where('users.id', auth()->id());
                }]);
            })
            ->get();

        // Calculate additional data for each course
        $courses->each(function ($course) {
            $course->is_enrolled = auth()->check() ? $course->students->contains(auth()->id()) : false;
            $course->completion_percentage = $course->completion_percentage;
            $course->mastered_topics_count = $course->mastered_topics_count;
        });

        return view('courses', compact('courses'));
    }

    public function show(Course $course)
    {
        $course->load('topics');
        $isEnrolled = auth()->check() && $course->students->contains(auth()->id());
        return view('courses.info', compact('course', 'isEnrolled'));
    }

    public function enroll(Course $course)
    {
        // Check if user is already enrolled
        if (auth()->user()->courses->contains($course->id)) {
            return redirect()->route('courses.index')
                ->with('info', 'You are already enrolled in this course.');
        }

        // Check if user has access to enroll
        if (!auth()->user()->is_admin && !auth()->user()->hasAccessToCourse($course->id)) {
            return redirect()->route('courses.index')
                ->with('error', 'You need special access to enroll in this course. Please contact an administrator.');
        }

        auth()->user()->courses()->syncWithoutDetaching([$course->id]);
        return redirect()->route('courses.index')
            ->with('success', 'Successfully enrolled in ' . $course->name);
    }
}