<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\DB;

class TrackUserActivity
{
    public function handle(Request $request, Closure $next)
    {
        // Generate a unique visitor ID if not exists
        if (!Session::has('visitor_id')) {
            Session::put('visitor_id', uniqid('visitor_', true));
        }

        // Update or create visitor record
        DB::table('visitors')->updateOrInsert(
            ['visitor_id' => Session::get('visitor_id')],
            ['last_active_at' => now()]
        );

        return $next($request);
    }
} 