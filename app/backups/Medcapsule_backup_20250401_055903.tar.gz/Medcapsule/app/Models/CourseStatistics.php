<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CourseStatistics extends Model
{
    protected $fillable = [
        'course_id',
        'topics_count',
        'cases_count',
        'questions_count',
        'enrolled_students_count'
    ];

    public function course()
    {
        return $this->belongsTo(Course::class);
    }
}
