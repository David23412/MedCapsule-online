<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserTopicProgress extends Model
{
    protected $table = 'user_topic_progress';
    
    protected $fillable = [
        'user_id',
        'topic_id',
        'completed'
    ];

    protected $casts = [
        'completed' => 'boolean'
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function topic()
    {
        return $this->belongsTo(Topic::class);
    }
} 