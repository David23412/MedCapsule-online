<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Course extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'description',
        'image_url'
    ];

    // ✅ Define relationship: A course has many topics
    public function topics()
    {
        return $this->hasMany(Topic::class);
    }

    public function questions()
    {
        return $this->hasManyThrough(Question::class, Topic::class);
    }

    public function students()
    {
        return $this->belongsToMany(User::class, 'course_user')
                    ->withTimestamps();
    }

    public function getTopicsCountAttribute()
    {
        return $this->topics()
            ->where('name', 'not like', '% cases')
            ->count();
    }

    public function getCasesCountAttribute()
    {
        return $this->topics()
            ->where('name', 'like', '% cases')
            ->count();
    }

    public function getQuestionsCountAttribute()
    {
        return $this->questions()->count();
    }

    public function getEnrolledStudentsCountAttribute()
    {
        return $this->students()->count();
    }

    public function getCompletionPercentageAttribute()
    {
        if (!auth()->check()) {
            return 0;
        }
        
        $result = $this->topics()
            ->select(DB::raw('COALESCE(AVG(percentage_grade), 0) as avg_grade'))
            ->first();
            
        return round($result->avg_grade ?? 0, 2);
    }

    public function getMasteredTopicsCountAttribute()
    {
        if (!auth()->check()) {
            return 0;
        }
        
        return $this->topics()
            ->where('percentage_grade', '>=', 80)
            ->count();
    }
}