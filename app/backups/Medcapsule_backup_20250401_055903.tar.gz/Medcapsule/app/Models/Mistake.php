<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class Mistake extends Model
{
    use HasFactory;

    // Make sure you're allowing these fields to be mass-assigned
    protected $fillable = [
        'user_id',
        'question_id',
        'submitted_answer',
        'last_attempt_date',
        'interval',
        'ease_factor',
        'next_review_date',
        'consecutive_correct',
        'times_reviewed',
        'stage'
    ];

    protected $casts = [
        'last_attempt_date' => 'datetime',
        'next_review_date' => 'datetime',
    ];

    // Disable timestamps if you're not using them
    public $timestamps = false;

    // Set the primary key to be composite
    protected $primaryKey = ['user_id', 'question_id'];
    public $incrementing = false;

    // Define the stages in days
    private const STAGES = [1, 3, 7, 14, 30];
    private const MAX_STAGE = 4; // 0-based index of the last stage

    /**
     * Get the value indicating whether the IDs are incrementing.
     *
     * @return bool
     */
    public function getIncrementing()
    {
        return false;
    }

    /**
     * Get the primary key for the model.
     *
     * @return string
     */
    public function getKeyName()
    {
        return ['user_id', 'question_id'];
    }

    /**
     * Get the value of the model's primary key.
     *
     * @return mixed
     */
    public function getKey()
    {
        $attributes = [];
        foreach ($this->getKeyName() as $key) {
            $attributes[$key] = $this->getAttribute($key);
        }
        return $attributes;
    }

    /**
     * Set the keys for a save update query.
     *
     * @param  \Illuminate\Database\Eloquent\Builder  $query
     * @return \Illuminate\Database\Eloquent\Builder
     */
    protected function setKeysForSaveQuery($query)
    {
        foreach ($this->getKeyName() as $key) {
            if (isset($this->$key)) {
                $query->where($key, '=', $this->$key);
            } else {
                throw new \Exception("Composite key value missing for key: $key");
            }
        }
        return $query;
    }

    /**
     * Define the relationship with the Question model.
     */
    public function question()
    {
        return $this->belongsTo(Question::class, 'question_id');
    }

    /**
     * Initialize Anki algorithm parameters for a new mistake.
     */
    public function initializeAnki()
    {
        $this->times_reviewed = 0;
        $this->consecutive_correct = 0;
        $this->stage = 0; // Start at first stage
        $this->next_review_date = now()->addDays(self::STAGES[0]);
    }

    /**
     * Update Anki parameters based on user rating.
     */
    public function updateAnki($rating)
    {
        if ($rating === 'again') {
            // Reset to first stage
            $this->stage = 0;
            $this->consecutive_correct = 0;
            $this->next_review_date = now()->addDays(self::STAGES[0]);
        } else {
            // Move to next stage
            $this->stage = min($this->stage + 1, self::MAX_STAGE);
            $this->consecutive_correct++;
            $this->next_review_date = now()->addDays(self::STAGES[$this->stage]);
        }
        
        $this->times_reviewed++;
        $this->last_attempt_date = now();
        $this->save();
    }

    /**
     * Check if the mistake is due for review.
     */
    public function isDueForReview()
    {
        return $this->next_review_date <= now();
    }

    /**
     * Ensure the question exists before saving or updating the mistake.
     */
    public static function boot()
    {
        parent::boot();

        // Listen to the 'creating' event and check if the question exists
        static::creating(function ($mistake) {
            $question = Question::find($mistake->question_id);
            if (!$question) {
                Log::warning('⚠️ Attempting to create a mistake with invalid question_id', [
                    'question_id' => $mistake->question_id,
                    'user_id' => $mistake->user_id
                ]);
                throw new \Exception('Invalid question_id provided.');
            }
            
            // Initialize Anki parameters for new mistakes
            $mistake->initializeAnki();
        });

        // You can also add checks during the updating event if needed
        static::updating(function ($mistake) {
            $question = Question::find($mistake->question_id);
            if (!$question) {
                Log::warning('⚠️ Attempting to update a mistake with invalid question_id', [
                    'question_id' => $mistake->question_id,
                    'user_id' => $mistake->user_id
                ]);
                throw new \Exception('Invalid question_id provided.');
            }
        });
    }

    /**
     * Ensure question exists when fetching mistake data.
     */
    public function getQuestionAttribute()
    {
        // Attempt to fetch the related question; if not found, log it.
        $question = $this->belongsTo(Question::class, 'question_id')->first();
        if (!$question) {
            Log::warning('⚠️ Question not found for mistake', [
                'user_id' => $this->user_id,
                'question_id' => $this->question_id
            ]);
        }

        return $question;
    }

    public function isMastered()
    {
        return $this->stage === self::MAX_STAGE;
    }

    public function getStageProgress()
    {
        return [
            'current_stage' => $this->stage,
            'total_stages' => self::MAX_STAGE + 1,
            'next_review' => $this->next_review_date,
            'is_mastered' => $this->isMastered()
        ];
    }
}