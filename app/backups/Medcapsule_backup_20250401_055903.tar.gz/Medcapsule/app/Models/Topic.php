<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Topic extends Model
{
    use HasFactory;

    // Make 'percentage_grade' and 'last_attempt_date' mass assignable
    protected $fillable = ['name', 'course_id', 'description', 'order', 'percentage_grade', 'last_attempt_date'];

    // Cast percentage_grade to float and last_attempt_date to datetime
    protected $casts = [
        'percentage_grade' => 'float',
        'last_attempt_date' => 'datetime'
    ];

    // Add the questions relationship
    public function questions()
    {
        return $this->hasMany(Question::class);
    }

    // Relationship: A topic belongs to a course
    public function course()
    {
        return $this->belongsTo(Course::class);
    }

    public function userProgress()
    {
        return $this->hasMany(UserTopicProgress::class);
    }

    protected static function boot()
    {
        parent::boot();
        
        // Update questions_count when the topic is retrieved
        static::retrieved(function ($topic) {
            $count = $topic->questions()->count();
            if ($topic->questions_count !== $count) {
                $topic->questions_count = $count;
                $topic->save();
            }
        });
    }
}